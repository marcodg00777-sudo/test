"""KREM Plant Headcount Planning - FastAPI backend."""
from __future__ import annotations

import io
import logging
import os
import re
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, ConfigDict, Field, field_validator
from starlette.middleware.cors import CORSMiddleware

from seed_data import SEED_AREAS, SEED_MILESTONES, SEED_POSITIONS
from exports import build_headcount_pdf, build_headcount_xlsx, build_krem_format_xlsx
from excel_import import parse_headcount_workbook

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

app = FastAPI(title="KREM Headcount Planner")
api = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("hc")


# ------------------------------ Helpers ----------------------------------

def new_id() -> str:
    return str(uuid.uuid4())


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def strip_id(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


CLASSIFICATIONS = {"DL", "IL", "DLNUN"}
ORIGINS = {"KEMMX", "KOMEX"}
SHIFTS = {"1st", "2nd", "3rd", "N/A"}
MILESTONE_TYPES = {"transfer", "trial_run", "sop", "custom"}
POSITION_STATES = {"occupied", "vacant", "tbd", "planned"}
COST_CENTER_RX = re.compile(r"^\d{5}$")


# ------------------------------ Models -----------------------------------

class AreaCreate(BaseModel):
    name: str
    code: Optional[str] = None
    description: Optional[str] = ""
    cost_center: Optional[str] = None
    archived: bool = False


class Area(AreaCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class PositionCreate(BaseModel):
    name: str
    area_id: str
    classification: str  # DL | IL | DLNUN
    shift: str = "N/A"
    order: int = 0
    level: Optional[int] = None                # 1..7 (1 = top of hierarchy)
    reports_to_position_id: Optional[str] = None
    state: str = "planned"                     # occupied | vacant | tbd | planned


class PositionUpdate(BaseModel):
    name: Optional[str] = None
    area_id: Optional[str] = None
    classification: Optional[str] = None
    shift: Optional[str] = None
    order: Optional[int] = None
    level: Optional[int] = None
    reports_to_position_id: Optional[str] = None
    state: Optional[str] = None


class Position(PositionCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)

    @field_validator("level", mode="before")
    @classmethod
    def _coerce_bad_level(cls, v):
        """Legacy/corrupted docs may have a non-numeric level (e.g. a stray id).
        Treat that as unset instead of failing the whole /positions response."""
        if v is None or v == "":
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None


class PersonCreate(BaseModel):
    name: str = "TBD"
    position_id: Optional[str] = None
    origin: Optional[str] = None  # KEMMX | KOMEX
    classification: Optional[str] = None
    shift: Optional[str] = None
    hire_date: Optional[str] = None  # ISO date
    status: str = "planned"  # planned | active | training | inactive
    employee_id: Optional[str] = None
    custom_fields: Dict[str, Any] = Field(default_factory=dict)
    notes: Optional[str] = ""


class PersonUpdate(BaseModel):
    name: Optional[str] = None
    position_id: Optional[str] = None
    origin: Optional[str] = None
    classification: Optional[str] = None
    shift: Optional[str] = None
    hire_date: Optional[str] = None
    status: Optional[str] = None
    employee_id: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None


class Person(PersonCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class MilestoneCreate(BaseModel):
    name: str
    type: str = "custom"  # transfer | trial_run | sop | custom
    date: str  # ISO YYYY-MM-DD
    year: int
    cw: int
    color: Optional[str] = None
    description: Optional[str] = ""


class MilestoneUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    date: Optional[str] = None
    year: Optional[int] = None
    cw: Optional[int] = None
    color: Optional[str] = None
    description: Optional[str] = None


class Milestone(MilestoneCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class CellUpdate(BaseModel):
    position_id: str
    year: int
    cw: int
    count: int


class BulkCellUpdate(BaseModel):
    cells: List[CellUpdate]


# ------------------------------ Areas ------------------------------------

@api.get("/areas", response_model=List[Area])
async def list_areas():
    docs = await db.areas.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    return docs


@api.post("/areas", response_model=Area)
async def create_area(body: AreaCreate):
    if body.cost_center:
        if not COST_CENTER_RX.match(body.cost_center):
            raise HTTPException(400, "cost_center must be exactly 5 numeric digits")
        exists = await db.areas.find_one({"cost_center": body.cost_center}, {"_id": 0})
        if exists:
            raise HTTPException(400, f"Cost center {body.cost_center} is already used by '{exists['name']}'")
    a = Area(**body.model_dump())
    await db.areas.insert_one(a.model_dump())
    return a


@api.patch("/areas/{area_id}", response_model=Area)
async def update_area(area_id: str, body: AreaCreate):
    updates = body.model_dump(exclude_none=True)
    if "cost_center" in updates and updates["cost_center"]:
        if not COST_CENTER_RX.match(updates["cost_center"]):
            raise HTTPException(400, "cost_center must be exactly 5 numeric digits")
        clash = await db.areas.find_one(
            {"cost_center": updates["cost_center"], "id": {"$ne": area_id}},
            {"_id": 0},
        )
        if clash:
            raise HTTPException(400, f"Cost center {updates['cost_center']} is already used by '{clash['name']}'")
    res = await db.areas.find_one_and_update(
        {"id": area_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Area not found")
    return strip_id(res)


@api.post("/areas/{area_id}/archive")
async def archive_area(area_id: str, archived: bool = True):
    res = await db.areas.find_one_and_update(
        {"id": area_id}, {"$set": {"archived": archived}}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Area not found")
    return {"ok": True, "id": area_id, "archived": archived}


@api.delete("/areas/{area_id}")
async def delete_area(area_id: str):
    positions = await db.positions.count_documents({"area_id": area_id})
    if positions > 0:
        raise HTTPException(400, f"Area is used by {positions} position(s)")
    result = await db.areas.delete_one({"id": area_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Area not found")
    return {"ok": True}


# ------------------------------ Positions --------------------------------

@api.get("/positions", response_model=List[Position])
async def list_positions():
    docs = await db.positions.find({}, {"_id": 0}).sort([("order", 1), ("name", 1)]).to_list(5000)
    return docs


async def _validate_position_hierarchy(
    pos_id: Optional[str],
    level: Optional[int],
    reports_to: Optional[str],
) -> None:
    """Enforce level (1-7) and reports_to rules (no self, higher level = smaller number, no cycles)."""
    if level is not None and (level < 1 or level > 7):
        raise HTTPException(400, "level must be between 1 and 7")
    if not reports_to:
        return
    if pos_id and reports_to == pos_id:
        raise HTTPException(400, "A position cannot report to itself")

    target = await db.positions.find_one({"id": reports_to}, {"_id": 0})
    if not target:
        raise HTTPException(400, f"reports_to_position_id {reports_to} does not exist")
    target_level = target.get("level")
    if level is not None and target_level is not None:
        if target_level >= level:
            raise HTTPException(
                400,
                f"reports_to '{target['name']}' has level {target_level}; "
                f"must be strictly higher rank (smaller number) than {level}",
            )
    # Cycle detection: walk up from target and make sure we don't hit pos_id
    if pos_id:
        current = target
        seen = {pos_id}
        for _ in range(30):
            cur_reports = current.get("reports_to_position_id")
            if not cur_reports:
                break
            if cur_reports in seen:
                raise HTTPException(400, "This would create a cycle in the reporting chain")
            seen.add(cur_reports)
            current = await db.positions.find_one({"id": cur_reports}, {"_id": 0})
            if not current:
                break


@api.post("/positions", response_model=Position)
async def create_position(body: PositionCreate):
    if body.classification not in CLASSIFICATIONS:
        raise HTTPException(400, f"classification must be one of {CLASSIFICATIONS}")
    if body.state not in POSITION_STATES:
        raise HTTPException(400, f"state must be one of {POSITION_STATES}")
    await _validate_position_hierarchy(None, body.level, body.reports_to_position_id)
    p = Position(**body.model_dump())
    await db.positions.insert_one(p.model_dump())
    return p


@api.patch("/positions/{position_id}", response_model=Position)
async def update_position(position_id: str, body: PositionUpdate):
    updates = body.model_dump(exclude_none=True)
    if "classification" in updates and updates["classification"] not in CLASSIFICATIONS:
        raise HTTPException(400, f"classification must be one of {CLASSIFICATIONS}")
    if "state" in updates and updates["state"] not in POSITION_STATES:
        raise HTTPException(400, f"state must be one of {POSITION_STATES}")
    # Merge with current doc for hierarchy checks
    if "level" in updates or "reports_to_position_id" in updates:
        current = await db.positions.find_one({"id": position_id}, {"_id": 0})
        if not current:
            raise HTTPException(404, "Position not found")
        merged_level  = updates.get("level", current.get("level"))
        merged_report = updates.get("reports_to_position_id", current.get("reports_to_position_id"))
        await _validate_position_hierarchy(position_id, merged_level, merged_report)
    res = await db.positions.find_one_and_update(
        {"id": position_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Position not found")
    return strip_id(res)


@api.get("/positions/hierarchy")
async def positions_hierarchy(area_id: Optional[str] = None, cost_center: Optional[str] = None):
    """Return the org tree as a list of roots each with recursive `children`."""
    areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    area_by_id = {a["id"]: a for a in areas}
    area_by_cc = {a.get("cost_center"): a for a in areas if a.get("cost_center")}

    positions = await db.positions.find({}, {"_id": 0}).sort([("level", 1), ("order", 1), ("name", 1)]).to_list(5000)
    people = await db.people.find({"position_id": {"$ne": None}}, {"_id": 0}).to_list(10000)
    person_by_pos: Dict[str, List[dict]] = {}
    for p in people:
        person_by_pos.setdefault(p["position_id"], []).append(p)

    # Optional area / cc filter
    if cost_center:
        area = area_by_cc.get(cost_center)
        if not area:
            return {"roots": []}
        area_id = area["id"]
    if area_id:
        positions = [p for p in positions if p["area_id"] == area_id]

    pos_by_id = {p["id"]: {**p, "children": [], "assigned": person_by_pos.get(p["id"], [])} for p in positions}
    roots: List[dict] = []
    for p in positions:
        parent = p.get("reports_to_position_id")
        if parent and parent in pos_by_id:
            pos_by_id[parent]["children"].append(pos_by_id[p["id"]])
        else:
            roots.append(pos_by_id[p["id"]])

    # Sort by level, then name at each level
    def _sort(node):
        node["children"].sort(key=lambda c: (c.get("level") or 99, c.get("name") or ""))
        for c in node["children"]:
            _sort(c)
    for r in roots:
        _sort(r)
    roots.sort(key=lambda c: (c.get("level") or 99, c.get("name") or ""))
    # Add area info to each node for the frontend
    for pid, node in pos_by_id.items():
        area = area_by_id.get(node["area_id"])
        node["area_name"] = area["name"] if area else "?"
        node["cost_center"] = area.get("cost_center") if area else None
    return {"roots": roots}


@api.delete("/positions/{position_id}")
async def delete_position(position_id: str):
    await db.headcount_plan.delete_one({"position_id": position_id})
    await db.people.update_many({"position_id": position_id}, {"$set": {"position_id": None}})
    result = await db.positions.delete_one({"id": position_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Position not found")
    return {"ok": True}


# ------------------------------ People -----------------------------------

@api.get("/people", response_model=List[Person])
async def list_people():
    docs = await db.people.find({}, {"_id": 0}).sort([("status", 1), ("name", 1)]).to_list(10000)
    return docs


@api.post("/people", response_model=Person)
async def create_person(body: PersonCreate):
    p = Person(**body.model_dump())
    await db.people.insert_one(p.model_dump())
    return p


@api.patch("/people/{person_id}", response_model=Person)
async def update_person(person_id: str, body: PersonUpdate):
    updates = body.model_dump(exclude_none=True)
    res = await db.people.find_one_and_update(
        {"id": person_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Person not found")
    return strip_id(res)


@api.delete("/people/{person_id}")
async def delete_person(person_id: str):
    result = await db.people.delete_one({"id": person_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Person not found")
    return {"ok": True}


# ------------------------------ Milestones -------------------------------

@api.get("/milestones", response_model=List[Milestone])
async def list_milestones():
    docs = await db.milestones.find({}, {"_id": 0}).sort([("year", 1), ("cw", 1)]).to_list(1000)
    return docs


@api.post("/milestones", response_model=Milestone)
async def create_milestone(body: MilestoneCreate):
    if body.type not in MILESTONE_TYPES:
        raise HTTPException(400, f"type must be one of {MILESTONE_TYPES}")
    m = Milestone(**body.model_dump())
    await db.milestones.insert_one(m.model_dump())
    return m


@api.patch("/milestones/{milestone_id}", response_model=Milestone)
async def update_milestone(milestone_id: str, body: MilestoneUpdate):
    updates = body.model_dump(exclude_none=True)
    if "type" in updates and updates["type"] not in MILESTONE_TYPES:
        raise HTTPException(400, f"type must be one of {MILESTONE_TYPES}")
    res = await db.milestones.find_one_and_update(
        {"id": milestone_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Milestone not found")
    return strip_id(res)


@api.delete("/milestones/{milestone_id}")
async def delete_milestone(milestone_id: str):
    result = await db.milestones.delete_one({"id": milestone_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Milestone not found")
    return {"ok": True}


# ------------------------------ Headcount Plan ---------------------------

def cell_key(year: int, cw: int) -> str:
    return f"{year}-CW{cw:02d}"


@api.get("/headcount")
async def get_headcount():
    """Return {position_id: {"2025-CW27": count, ...}} for every position."""
    docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    return {d["position_id"]: d.get("cells", {}) for d in docs}


@api.post("/headcount/cell")
async def set_cell(body: CellUpdate):
    key = cell_key(body.year, body.cw)
    if body.count < 0:
        raise HTTPException(400, "count must be >= 0")
    await db.headcount_plan.update_one(
        {"position_id": body.position_id},
        {"$set": {f"cells.{key}": body.count, "position_id": body.position_id}},
        upsert=True,
    )
    return {"ok": True, "position_id": body.position_id, "key": key, "count": body.count}


@api.post("/headcount/bulk")
async def bulk_cells(body: BulkCellUpdate):
    for c in body.cells:
        if c.count < 0:
            raise HTTPException(400, "count must be >= 0")
        key = cell_key(c.year, c.cw)
        await db.headcount_plan.update_one(
            {"position_id": c.position_id},
            {"$set": {f"cells.{key}": c.count, "position_id": c.position_id}},
            upsert=True,
        )
    return {"ok": True, "count": len(body.cells)}


# ------------------------------ Reports ----------------------------------

async def _load_report_context(year_start: int, cw_start: int, num_weeks: int = 52):
    areas = await db.areas.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    positions = await db.positions.find({}, {"_id": 0}).sort([("order", 1), ("name", 1)]).to_list(5000)
    plan_docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    milestones = await db.milestones.find({}, {"_id": 0}).sort([("year", 1), ("cw", 1)]).to_list(1000)
    plan = {d["position_id"]: d.get("cells", {}) for d in plan_docs}

    # Compute the list of (year, cw) for the fiscal year range.
    weeks = []
    y, w = year_start, cw_start
    for _ in range(num_weeks):
        weeks.append((y, w))
        w += 1
        if w > 52:
            w = 1
            y += 1
    return areas, positions, plan, milestones, weeks


@api.get("/reports/headcount.xlsx")
async def export_xlsx(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    areas, positions, plan, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_headcount_xlsx(areas, positions, plan, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="headcount_FY{year}.xlsx"'},
    )


@api.get("/reports/headcount.pdf")
async def export_pdf(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    areas, positions, plan, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_headcount_pdf(areas, positions, plan, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="headcount_FY{year}.pdf"'},
    )


@api.get("/reports/headcount_krem.xlsx")
async def export_krem_xlsx(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    """Excel matching the original KREM template layout, with embedded charts."""
    areas, positions, plan, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_krem_format_xlsx(areas, positions, plan, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="KREM_headcount_FY{year}.xlsx"'},
    )


# ------------------------------ Seed / Stats -----------------------------

@api.post("/seed")
async def seed(reset: bool = False):
    """Populate the DB with default KREM plant structure. Idempotent unless reset=True."""
    if reset:
        await db.areas.delete_many({})
        await db.positions.delete_many({})
        await db.milestones.delete_many({})
        await db.headcount_plan.delete_many({})

    area_by_code: Dict[str, str] = {}
    existing_areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    for a in existing_areas:
        area_by_code[a.get("code") or a["name"]] = a["id"]

    for name, code, desc in SEED_AREAS:
        if code in area_by_code:
            continue
        a = Area(name=name, code=code, description=desc)
        await db.areas.insert_one(a.model_dump())
        area_by_code[code] = a.id

    existing_positions = {p["name"] for p in await db.positions.find({}, {"_id": 0}).to_list(5000)}
    for i, (name, area_code, classification, shift) in enumerate(SEED_POSITIONS):
        if name in existing_positions:
            continue
        area_id = area_by_code.get(area_code)
        if not area_id:
            continue
        p = Position(name=name, area_id=area_id, classification=classification, shift=shift, order=i)
        await db.positions.insert_one(p.model_dump())

    existing_ms = {m["name"] for m in await db.milestones.find({}, {"_id": 0}).to_list(1000)}
    for name, mtype, iso_date, y, w, color in SEED_MILESTONES:
        if name in existing_ms:
            continue
        m = Milestone(name=name, type=mtype, date=iso_date, year=y, cw=w, color=color)
        await db.milestones.insert_one(m.model_dump())

    return {"ok": True}


@api.get("/stats")
async def stats():
    areas = await db.areas.count_documents({})
    positions_docs = await db.positions.find({}, {"_id": 0}).to_list(5000)
    positions_total = len(positions_docs)
    by_class: Dict[str, int] = {"DL": 0, "IL": 0, "DLNUN": 0}
    for p in positions_docs:
        by_class[p["classification"]] = by_class.get(p["classification"], 0) + 1

    people_docs = await db.people.find({}, {"_id": 0}).to_list(10000)
    tbd = sum(1 for p in people_docs if (p.get("name") or "").strip().upper() == "TBD")
    assigned = sum(1 for p in people_docs if (p.get("name") or "").strip().upper() != "TBD")

    milestones = await db.milestones.count_documents({})

    plan_docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    peak = 0
    total_planned = 0
    for d in plan_docs:
        for _, v in (d.get("cells") or {}).items():
            total_planned += int(v)
            if int(v) > peak:
                peak = int(v)

    return {
        "areas": areas,
        "positions_total": positions_total,
        "positions_by_class": by_class,
        "people_total": len(people_docs),
        "people_tbd": tbd,
        "people_assigned": assigned,
        "milestones": milestones,
        "planned_total_sum": total_planned,
        "planned_peak_single_cell": peak,
    }


@api.get("/")
async def root():
    return {"service": "KREM Headcount Planner", "time": now_iso()}


# ------------------------------ Excel Import -----------------------------

@api.post("/import/excel")
async def import_excel(
    file: UploadFile = File(...),
    year_start: int = 2025,
    reset_cells: bool = False,
    replace_all: bool = False,
):
    """Import positions and headcount cells from the KREM Excel template.

    - Ensures required areas exist (creates missing ones)
    - Creates missing positions (matched by exact name)
    - Upserts headcount cells (position × CW)
    - If `reset_cells` is true, wipes the whole `headcount_plan` collection first
    - If `replace_all` is true, wipes positions and headcount_plan first
      (keeps areas, people and milestones intact)
    """
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload an .xlsx file")

    contents = await file.read()
    try:
        parsed_positions, parsed_cells = parse_headcount_workbook(contents, year_start=year_start)
    except Exception as e:
        raise HTTPException(400, f"Could not parse workbook: {e}")

    if replace_all:
        await db.positions.delete_many({})
        await db.headcount_plan.delete_many({})

    # 1. Ensure areas exist (create if missing)
    needed_area_codes = {p["area_code"] for p in parsed_positions}
    existing_areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    area_by_code = {a.get("code") or a["name"]: a for a in existing_areas}

    default_area_names = {c: n for n, c, _ in SEED_AREAS}
    for code in needed_area_codes:
        if code not in area_by_code:
            a = Area(name=default_area_names.get(code, code), code=code, description="")
            await db.areas.insert_one(a.model_dump())
            area_by_code[code] = a.model_dump()

    # 2. Ensure positions exist (match by exact name)
    existing_positions = await db.positions.find({}, {"_id": 0}).to_list(5000)
    pos_by_name: Dict[str, dict] = {p["name"]: p for p in existing_positions}

    created_positions = 0
    for pp in parsed_positions:
        if pp["name"] in pos_by_name:
            continue
        area_id = area_by_code[pp["area_code"]]["id"]
        p = Position(
            name=pp["name"],
            area_id=area_id,
            classification=pp["classification"],
            shift=pp["shift"],
            order=len(pos_by_name) + created_positions,
        )
        await db.positions.insert_one(p.model_dump())
        pos_by_name[pp["name"]] = p.model_dump()
        created_positions += 1

    # 3. Reset cells if requested
    if reset_cells:
        await db.headcount_plan.delete_many({})

    # 4. Upsert cells. Group by position to minimise round-trips.
    cells_by_pos: Dict[str, Dict[str, int]] = {}
    for c in parsed_cells:
        pid = pos_by_name[c["position_name"]]["id"]
        key = f"{c['year']}-CW{c['cw']:02d}"
        cells_by_pos.setdefault(pid, {})[key] = c["count"]

    for pid, cells in cells_by_pos.items():
        set_map = {f"cells.{k}": v for k, v in cells.items()}
        set_map["position_id"] = pid
        await db.headcount_plan.update_one(
            {"position_id": pid},
            {"$set": set_map},
            upsert=True,
        )

    return {
        "ok": True,
        "positions_created": created_positions,
        "positions_matched": len(parsed_positions) - created_positions,
        "cells_written": len(parsed_cells),
        "positions_touched": len(cells_by_pos),
        "year_range": sorted({c["year"] for c in parsed_cells}) if parsed_cells else [],
    }


app.include_router(api)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def _shutdown():
    client.close()
