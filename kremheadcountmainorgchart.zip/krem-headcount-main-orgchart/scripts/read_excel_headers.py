from openpyxl import load_workbook
from pathlib import Path
import json
from datetime import date, datetime

FILES = [
    Path("positions.xlsx"),
    Path("indirectos smt KOMEX.xlsx"),
    Path("ops smt komex.xlsx"),
]

def find_header_row(ws, max_search=30):
    for r in range(1, min(max_search, ws.max_row) + 1):
        values = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
        # consider header row if it has at least 2 string cells
        str_count = sum(1 for v in values if isinstance(v, str) and v.strip())
        if str_count >= 2:
            return r, values
    return None, []

out = {}
for f in FILES:
    entry = {"exists": f.exists()}
    if not f.exists():
        out[str(f)] = entry
        continue
    wb = load_workbook(f, data_only=True)
    sheet = wb.active
    header_row, header_values = find_header_row(sheet)
    header = []
    preview = None
    if header_row:
        # trim trailing empties
        header = [ (v.strip() if isinstance(v, str) else v) for v in header_values ]
        # get first non-empty data row after header
        for r in range(header_row+1, min(sheet.max_row, header_row+20)+1):
            row_vals = [sheet.cell(r, c).value for c in range(1, sheet.max_column + 1)]
            if any(v is not None and (not isinstance(v, str) or v.strip()) for v in row_vals):
                preview = row_vals
                break
    entry.update({"header_row": header_row, "headers": header, "preview_row": preview})
    out[str(f)] = entry
def _serialize_value(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if v is None:
        return None
    try:
        return str(v).strip()
    except Exception:
        return repr(v)

# Serialize non-JSON types
for k, v in out.items():
    if isinstance(v, dict):
        if "headers" in v and v["headers"]:
            v["headers"] = [_serialize_value(x) for x in v["headers"]]
        if "preview_row" in v and v["preview_row"]:
            v["preview_row"] = [_serialize_value(x) for x in v["preview_row"]]

print(json.dumps(out, indent=2, ensure_ascii=False))
