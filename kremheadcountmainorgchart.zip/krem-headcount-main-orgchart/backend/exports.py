"""Excel & PDF export builders for the general headcount report."""
from __future__ import annotations

import io
from datetime import date, timedelta
from typing import Any, Dict, List, Tuple

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


CLASS_COLORS = {
    "DL":    "DBEAFE",   # blue-100
    "IL":    "E0E7FF",   # indigo-100
    "DLNUN": "FFEDD5",   # orange-100
}
CLASS_COLORS_PDF = {
    "DL":    colors.HexColor("#DBEAFE"),
    "IL":    colors.HexColor("#E0E7FF"),
    "DLNUN": colors.HexColor("#FFEDD5"),
}
MILESTONE_COLORS_XL = {
    "transfer":  "8B5CF6",
    "trial_run": "EAB308",
    "sop":       "10B981",
    "custom":    "64748B",
}
CELL_STATE_COLORS_XL = {
    "people": "DBEAFE",
    "mixed": "FEF3C7",
    "pending": "EDE9FE",
}


def _cw_label(y: int, w: int) -> str:
    return f"CW{w:02d}"


def _group_milestones_by_week(milestones: List[dict]) -> Dict[Tuple[int, int], List[dict]]:
    grouped: Dict[Tuple[int, int], List[dict]] = {}
    for milestone in sorted(milestones, key=lambda item: (item["year"], item["cw"], item.get("date", ""), item.get("name", ""))):
        grouped.setdefault((milestone["year"], milestone["cw"]), []).append(milestone)
    return grouped


def _cell_state_fill(planned: int, assigned: int) -> str | None:
    if planned <= 0:
        return None
    if assigned > 0 and planned == assigned:
        return CELL_STATE_COLORS_XL["people"]
    if assigned > 0 and planned > assigned:
        return CELL_STATE_COLORS_XL["mixed"]
    if assigned == 0:
        return CELL_STATE_COLORS_XL["pending"]
    return None


def build_headcount_xlsx(
    areas: List[dict],
    positions: List[dict],
    plan: Dict[str, Dict[str, int]],
    assignments: Dict[str, Dict[str, List[str]]],
    milestones: List[dict],
    weeks: List[Tuple[int, int]],
) -> io.BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = "Headcount"

    thin = Side(border_style="thin", color="CBD5E1")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="1E3A8A")
    header_font = Font(color="FFFFFF", bold=True, name="Calibri")
    area_map = {a["id"]: a for a in areas}
    ms_by_key = _group_milestones_by_week(milestones)
    positions_by_area: Dict[str, List[dict]] = {}
    for position in positions:
        positions_by_area.setdefault(position["area_id"], []).append(position)

    # --- Row 1: Title
    ws.cell(row=1, column=1, value="KREM Plant Headcount Plan").font = Font(bold=True, size=14, color="1E3A8A")
    ws.cell(row=1, column=1).alignment = Alignment(horizontal="left", vertical="center")

    # --- Row 2: Month labels
    prev_month_key = None
    for col_idx, (y, w) in enumerate(weeks, start=5):
        monday = _iso_week_monday(y, w)
        month_key = (monday.year, monday.month)
        if month_key != prev_month_key:
            cell = ws.cell(row=2, column=col_idx, value=MONTH_NAMES[monday.month - 1][:3])
            cell.font = Font(bold=True, color="1E3A8A", size=10)
            cell.alignment = Alignment(horizontal="left", vertical="center")
            prev_month_key = month_key

    # --- Row 3: Milestones label row
    ws.cell(row=3, column=1, value="Milestone").font = Font(bold=True, color="475569")
    for col_idx, (y, w) in enumerate(weeks, start=5):
        ms_group = ms_by_key.get((y, w))
        if ms_group:
            label = " · ".join(milestone["name"] for milestone in ms_group)
            primary = ms_group[0]
            cell = ws.cell(row=3, column=col_idx, value=label)
            cell.font = Font(bold=True, color="FFFFFF", size=9)
            cell.fill = PatternFill("solid", fgColor=MILESTONE_COLORS_XL.get(primary["type"], "64748B"))
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = border

    # --- Row 4: Header
    headers = ["Area", "Position", "Classification", "Shift"] + [_cw_label(y, w) for y, w in weeks] + ["Total"]
    for c_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=c_idx, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border

    # --- Data rows
    row_idx = 5
    for area in areas:
        area_positions = positions_by_area.get(area["id"], [])
        if not area_positions:
            continue

        for col_idx in range(1, 6 + len(weeks)):
            area_cell = ws.cell(row=row_idx, column=col_idx, value=area["name"] if col_idx == 1 else None)
            area_cell.fill = PatternFill("solid", fgColor="EFF6FF")
            area_cell.font = Font(bold=True, color="1E3A8A")
            area_cell.border = border
        row_idx += 1

        for p in area_positions:
            area_label = area.get("code") or area.get("name") or ""
            ws.cell(row=row_idx, column=1, value=area_label).border = border
            ws.cell(row=row_idx, column=2, value=p["name"]).border = border
            c_cell = ws.cell(row=row_idx, column=3, value=p["classification"])
            c_cell.border = border
            fill_hex = CLASS_COLORS.get(p["classification"])
            if fill_hex:
                c_cell.fill = PatternFill("solid", fgColor=fill_hex)
            ws.cell(row=row_idx, column=4, value=p.get("shift", "")).border = border

            cells = plan.get(p["id"], {})
            assignment_map = assignments.get(p["id"], {})
            total = 0
            for c_idx, (y, w) in enumerate(weeks, start=5):
                key = f"{y}-CW{w:02d}"
                val = int(cells.get(key, 0) or 0)
                assigned = len(assignment_map.get(key) or [])
                total += val
                cell = ws.cell(row=row_idx, column=c_idx, value=val if val else None)
                cell.border = border
                cell.alignment = Alignment(horizontal="center")
                fill = _cell_state_fill(val, assigned)
                if fill:
                    cell.fill = PatternFill("solid", fgColor=fill)
            t_cell = ws.cell(row=row_idx, column=5 + len(weeks), value=total)
            t_cell.font = Font(bold=True)
            t_cell.border = border
            t_cell.alignment = Alignment(horizontal="center")
            row_idx += 1

    # --- Totals row (Grand Total across all positions per week)
    grand_row = row_idx
    ws.cell(row=grand_row, column=1, value="GRAND TOTAL").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=grand_row, column=1).fill = PatternFill("solid", fgColor="1E3A8A")
    for col in range(2, 5):
        ws.cell(row=grand_row, column=col, value="").fill = PatternFill("solid", fgColor="1E3A8A")
    for c_idx, (y, w) in enumerate(weeks, start=5):
        key = f"{y}-CW{w:02d}"
        total = 0
        for p in positions:
            total += int(plan.get(p["id"], {}).get(key, 0) or 0)
        cell = ws.cell(row=grand_row, column=c_idx, value=total)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1E3A8A")
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

    # Column widths
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 8
    for i in range(5, 5 + len(weeks) + 1):
        ws.column_dimensions[get_column_letter(i)].width = 6

    ws.freeze_panes = "E5"

    stream = io.BytesIO()
    wb.save(stream)
    stream.seek(0)
    return stream


def build_headcount_pdf(
    areas: List[dict],
    positions: List[dict],
    plan: Dict[str, Dict[str, int]],
    milestones: List[dict],
    weeks: List[Tuple[int, int]],
) -> io.BytesIO:
    stream = io.BytesIO()
    doc = SimpleDocTemplate(
        stream,
        pagesize=landscape(A3),
        leftMargin=10 * mm,
        rightMargin=10 * mm,
        topMargin=10 * mm,
        bottomMargin=10 * mm,
    )
    styles = getSampleStyleSheet()
    story: List[Any] = []

    title = Paragraph(
        "<font color='#1E3A8A'><b>KREM Plant – Headcount Planning Report</b></font>",
        styles["Title"],
    )
    story.append(title)
    story.append(Spacer(1, 4 * mm))

    if milestones:
        ms_line = "  |  ".join(
            f"<b>{m['name']}</b> ({m['date']})" for m in sorted(milestones, key=lambda x: (x["year"], x["cw"]))
        )
        story.append(Paragraph(f"<font size='9' color='#475569'>Milestones: {ms_line}</font>", styles["Normal"]))
        story.append(Spacer(1, 4 * mm))

    area_map = {a["id"]: a for a in areas}
    ms_by_key = _group_milestones_by_week(milestones)

    header = ["Area", "Position", "Class", "Sh."] + [f"CW{w:02d}" for _, w in weeks] + ["Total"]
    data = [header]

    row_styles: List[tuple] = []
    for i, p in enumerate(positions, start=1):
        area = area_map.get(p["area_id"])
        cells = plan.get(p["id"], {})
        row = [
            (area["name"] if area else ""),
            p["name"],
            p["classification"],
            p.get("shift", ""),
        ]
        total = 0
        for (y, w) in weeks:
            v = int(cells.get(f"{y}-CW{w:02d}", 0) or 0)
            total += v
            row.append(str(v) if v else "")
        row.append(str(total))
        data.append(row)

        bg = CLASS_COLORS_PDF.get(p["classification"])
        if bg is not None:
            row_styles.append(("BACKGROUND", (2, i), (2, i), bg))

    grand_row = ["GRAND TOTAL", "", "", ""]
    grand_total = 0
    for (y, w) in weeks:
        key = f"{y}-CW{w:02d}"
        s = sum(int(plan.get(p["id"], {}).get(key, 0) or 0) for p in positions)
        grand_total += s
        grand_row.append(str(s))
    grand_row.append(str(grand_total))
    data.append(grand_row)

    col_widths = [22 * mm, 55 * mm, 14 * mm, 10 * mm] + [8 * mm] * len(weeks) + [12 * mm]
    tbl = Table(data, colWidths=col_widths, repeatRows=1)

    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E3A8A")),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 7),
        ("GRID",       (0, 0), (-1, -1), 0.25, colors.HexColor("#CBD5E1")),
        ("ALIGN",      (2, 1), (-1, -1), "CENTER"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#1E3A8A")),
        ("TEXTCOLOR",  (0, -1), (-1, -1), colors.white),
        ("FONTNAME",   (0, -1), (-1, -1), "Helvetica-Bold"),
    ]

    # Milestone column highlights
    for col_idx, (y, w) in enumerate(weeks, start=4):
        ms_group = ms_by_key.get((y, w))
        if ms_group:
            style_cmds.append(("BACKGROUND", (col_idx, 0), (col_idx, 0), colors.HexColor(ms_group[0].get("color") or "#64748B")))

    style_cmds.extend(row_styles)
    tbl.setStyle(TableStyle(style_cmds))
    story.append(tbl)

    doc.build(story)
    stream.seek(0)
    return stream


# ------------------------------------------------------------------
# KREM-format Excel export (matches the original template + charts)
# ------------------------------------------------------------------

def _iso_week_monday(year: int, week: int) -> date:
    jan4 = date(year, 1, 4)
    jan4_iso_weekday = jan4.isoweekday()  # Mon=1
    year_start_monday = jan4 - timedelta(days=jan4_iso_weekday - 1)
    return year_start_monday + timedelta(weeks=week - 1)


def build_krem_format_xlsx(
    areas: List[dict],
    positions: List[dict],
    plan: Dict[str, Dict[str, int]],
    assignments: Dict[str, Dict[str, List[str]]],
    milestones: List[dict],
    weeks: List[Tuple[int, int]],
) -> io.BytesIO:
    """Excel matching the original KREM template layout with native charts."""
    wb = Workbook()
    ws = wb.active
    ws.title = "HC SMT + BE (KREM)"

    thin = Side(border_style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ms_by_key = _group_milestones_by_week(milestones)

    # ---------- Row 1: Title
    ws.cell(row=1, column=2, value="KREM Plant - Headcount Planning").font = Font(
        bold=True, size=14, color="1E3A8A"
    )

    # ---------- Row 22: Month labels (one label per month, at first CW of the month)
    prev_month_key = None
    for idx, (y, w) in enumerate(weeks):
        col = 4 + idx  # data starts at column D
        monday = _iso_week_monday(y, w)
        month_key = (monday.year, monday.month)
        if month_key != prev_month_key:
            cell = ws.cell(row=22, column=col, value=MONTH_NAMES[monday.month - 1])
            cell.font = Font(bold=True, color="1E3A8A", size=10)
            cell.alignment = Alignment(horizontal="left")
            prev_month_key = month_key

    # ---------- Row 23: Header
    header_fill = PatternFill("solid", fgColor="1E3A8A")
    header_font = Font(color="FFFFFF", bold=True, size=10)

    ws.cell(row=23, column=2, value="AREA").fill = header_fill
    ws.cell(row=23, column=2).font = header_font
    ws.cell(row=23, column=2).alignment = Alignment(horizontal="center")
    ws.cell(row=23, column=2).border = border

    ws.cell(row=23, column=3, value="Staff").fill = header_fill
    ws.cell(row=23, column=3).font = header_font
    ws.cell(row=23, column=3).alignment = Alignment(horizontal="center")
    ws.cell(row=23, column=3).border = border

    for idx, (y, w) in enumerate(weeks):
        col = 4 + idx
        cell = ws.cell(row=23, column=col, value=f"CW{w:02d}")
        # Highlight milestone columns
        ms_group = ms_by_key.get((y, w))
        if ms_group:
            cell.fill = PatternFill("solid", fgColor=(ms_group[0].get("color") or "#8B5CF6").lstrip("#"))
            cell.font = Font(color="FFFFFF", bold=True, size=10)
        else:
            cell.fill = header_fill
            cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

    # ---------- Row 24: Section header
    section_fill = PatternFill("solid", fgColor="DBEAFE")
    ws.cell(row=24, column=2, value="SMT & BE KREM").font = Font(bold=True, color="1E3A8A", size=11)
    ws.cell(row=24, column=2).fill = section_fill
    ws.cell(row=24, column=2).alignment = Alignment(horizontal="left")

    # ---------- Rows 25+ : Position data
    row_idx = 25
    for p in positions:
        cells = plan.get(p["id"], {})
        assignment_map = assignments.get(p["id"], {})
        # Column B: position name (as-is; typically includes area prefix)
        b = ws.cell(row=row_idx, column=2, value=p["name"])
        b.border = border
        # Column C: classification (Staff)
        c = ws.cell(row=row_idx, column=3, value=p["classification"])
        c.border = border
        c.alignment = Alignment(horizontal="center")
        fill_hex = CLASS_COLORS.get(p["classification"])
        if fill_hex:
            c.fill = PatternFill("solid", fgColor=fill_hex)
        # CW columns
        for idx, (y, w) in enumerate(weeks):
            col = 4 + idx
            key = f"{y}-CW{w:02d}"
            val = int(cells.get(key, 0) or 0)
            cell = ws.cell(row=row_idx, column=col, value=val)
            cell.border = border
            cell.alignment = Alignment(horizontal="center")
            fill = _cell_state_fill(val, len(assignment_map.get(key) or []))
            if fill:
                cell.fill = PatternFill("solid", fgColor=fill)
        row_idx += 1

    # ---------- Grand Total row
    total_row_idx = row_idx
    gt = ws.cell(row=total_row_idx, column=2, value="Grand Total")
    gt.font = Font(bold=True, color="FFFFFF")
    gt.fill = PatternFill("solid", fgColor="1E3A8A")
    gt.alignment = Alignment(horizontal="left")

    ws.cell(row=total_row_idx, column=3, value="").fill = PatternFill("solid", fgColor="1E3A8A")

    for idx, (y, w) in enumerate(weeks):
        col = 4 + idx
        key = f"{y}-CW{w:02d}"
        total = sum(int(plan.get(p["id"], {}).get(key, 0) or 0) for p in positions)
        cell = ws.cell(row=total_row_idx, column=col, value=total)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1E3A8A")
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

    # ---------- Column widths + freeze panes
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 42
    ws.column_dimensions["C"].width = 8
    for i in range(4, 4 + len(weeks)):
        ws.column_dimensions[get_column_letter(i)].width = 6
    ws.freeze_panes = "D24"

    # =====================================================================
    # Sheet 2 : Charts (with supporting data tables)
    # =====================================================================
    ch = wb.create_sheet(title="Charts")

    # --- Table A : Weekly totals per classification (DL / IL / DLNUN)
    ch.cell(row=1, column=1, value="Week")
    ch.cell(row=1, column=2, value="DL")
    ch.cell(row=1, column=3, value="IL")
    ch.cell(row=1, column=4, value="DLNUN")
    ch.cell(row=1, column=5, value="Total")
    for c in range(1, 6):
        ch.cell(row=1, column=c).font = Font(bold=True, color="FFFFFF")
        ch.cell(row=1, column=c).fill = header_fill
        ch.cell(row=1, column=c).alignment = Alignment(horizontal="center")

    class_by_pos = {p["id"]: p["classification"] for p in positions}
    for idx, (y, w) in enumerate(weeks):
        r = 2 + idx
        key = f"{y}-CW{w:02d}"
        totals = {"DL": 0, "IL": 0, "DLNUN": 0}
        for pid, cells in plan.items():
            cls = class_by_pos.get(pid)
            if cls in totals:
                totals[cls] += int(cells.get(key, 0) or 0)
        ch.cell(row=r, column=1, value=f"CW{w:02d}")
        ch.cell(row=r, column=2, value=totals["DL"])
        ch.cell(row=r, column=3, value=totals["IL"])
        ch.cell(row=r, column=4, value=totals["DLNUN"])
        ch.cell(row=r, column=5, value=totals["DL"] + totals["IL"] + totals["DLNUN"])

    n_weeks = len(weeks)
    last_row = 1 + n_weeks

    # Stacked bar chart: Headcount by week (DL/IL/DLNUN)
    stacked = BarChart()
    stacked.type = "col"
    stacked.style = 11
    stacked.grouping = "stacked"
    stacked.overlap = 100
    stacked.title = "Headcount by week (DL / IL / DLNUN)"
    stacked.y_axis.title = "Headcount"
    stacked.x_axis.title = "Calendar Week"
    stacked.height = 10
    stacked.width = 25
    data = Reference(ch, min_col=2, max_col=4, min_row=1, max_row=last_row)
    cats = Reference(ch, min_col=1, max_col=1, min_row=2, max_row=last_row)
    stacked.add_data(data, titles_from_data=True)
    stacked.set_categories(cats)
    ch.add_chart(stacked, "G1")

    # Line chart: Total plant headcount trend
    line = LineChart()
    line.style = 12
    line.title = "Total plant headcount trend"
    line.y_axis.title = "Headcount"
    line.x_axis.title = "Calendar Week"
    line.height = 10
    line.width = 25
    line_data = Reference(ch, min_col=5, max_col=5, min_row=1, max_row=last_row)
    line.add_data(line_data, titles_from_data=True)
    line.set_categories(cats)
    ch.add_chart(line, "G22")

    # --- Table B : Distribution by area
    area_by_id = {a["id"]: a for a in areas}
    area_totals: Dict[str, int] = {}
    for pid, cells in plan.items():
        # sum all cells for this position
        s = sum(int(v or 0) for v in cells.values())
        # find area
        area_id = next((p["area_id"] for p in positions if p["id"] == pid), None)
        if not area_id:
            continue
        area_name = area_by_id.get(area_id, {}).get("name", "?")
        area_totals[area_name] = area_totals.get(area_name, 0) + s

    tbl_b_start = last_row + 4
    ch.cell(row=tbl_b_start, column=1, value="Area").font = Font(bold=True, color="FFFFFF")
    ch.cell(row=tbl_b_start, column=1).fill = header_fill
    ch.cell(row=tbl_b_start, column=2, value="Total person-weeks").font = Font(bold=True, color="FFFFFF")
    ch.cell(row=tbl_b_start, column=2).fill = header_fill

    row_p = tbl_b_start
    area_items = sorted(area_totals.items(), key=lambda x: -x[1])
    for name, total in area_items:
        if total == 0:
            continue
        row_p += 1
        ch.cell(row=row_p, column=1, value=name)
        ch.cell(row=row_p, column=2, value=total)

    if row_p > tbl_b_start:
        pie = PieChart()
        pie.title = "Total plan by area (person-weeks)"
        pie.height = 10
        pie.width = 15
        labels = Reference(ch, min_col=1, min_row=tbl_b_start + 1, max_row=row_p)
        data = Reference(ch, min_col=2, min_row=tbl_b_start, max_row=row_p)
        pie.add_data(data, titles_from_data=True)
        pie.set_categories(labels)
        pie.dataLabels = DataLabelList(showPercent=True)
        ch.add_chart(pie, "G44")

    ch.column_dimensions["A"].width = 14
    ch.column_dimensions["B"].width = 20
    ch.column_dimensions["C"].width = 12
    ch.column_dimensions["D"].width = 12
    ch.column_dimensions["E"].width = 12

    stream = io.BytesIO()
    wb.save(stream)
    stream.seek(0)
    return stream
