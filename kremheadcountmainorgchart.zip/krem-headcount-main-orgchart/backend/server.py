"""KREM Plant Headcount Planning - FastAPI backend."""
from __future__ import annotations

import logging
import os
import sys
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path


def _resolve_base_path() -> Path:
    """Resolve the folder that holds runtime resources (.env, dist, logs).

    When frozen with PyInstaller (--onedir), sys.executable points at the
    real .exe location, which is where we expect .env, dist/ and logs/ to
    live alongside the packaged app. In normal (non-frozen) execution this
    is simply the folder containing this file.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT_DIR = _resolve_base_path()

# ------------------------------ Logging -----------------------------------
# Set up logging BEFORE importing third-party packages so that any import
# failure inside a frozen build (missing hidden-import, etc.) is written to
# logs/app.log instead of crashing silently (--noconsole builds have no
# visible terminal for the user to read errors from).

LOG_DIR = ROOT_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("krem")
logger.setLevel(logging.INFO)
_log_format = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")

_file_handler = RotatingFileHandler(
    LOG_DIR / "app.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
_file_handler.setFormatter(_log_format)

# Attach to the root logger too, so third-party loggers (uvicorn, motor, etc.)
# also end up in logs/app.log.
_root_logger = logging.getLogger()
_root_logger.setLevel(logging.INFO)
_root_logger.addHandler(_file_handler)

# Only attach a console handler when a real console is available (dev mode).
# In a --noconsole frozen build sys.stdout/sys.stderr can be None; writing to
# them would raise and crash the app before anything is ever logged.
if sys.stdout is not None:
    _console_handler = logging.StreamHandler(sys.stdout)
    _console_handler.setFormatter(_log_format)
    _root_logger.addHandler(_console_handler)


def _show_fatal_error(message: str) -> None:
    """Log a fatal error and, on Windows, also show a blocking message box.

    This is what makes startup failures visible even in a --noconsole
    packaged build where there is no terminal window to read.
    """
    logger.critical(message)
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(
                0, message, "KREM Headcount Planner - Error", 0x10  # MB_ICONERROR
            )
        except Exception:
            pass


def _handle_uncaught_exception(exc_type, exc_value, exc_tb) -> None:
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    formatted = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    _show_fatal_error(f"La aplicacion se detuvo por un error inesperado:\n\n{formatted}")


sys.excepthook = _handle_uncaught_exception

logger.info("Iniciando KREM Headcount Planner. Carpeta base: %s", ROOT_DIR)

# ------------------------------ Imports ------------------------------------
# Wrapped so a missing dependency in a frozen build is logged/shown clearly
# instead of the process just disappearing with no explanation.
try:
    import io
    import uuid
    from datetime import date, datetime, timezone
    from typing import Any, Dict, List, Optional, Tuple

    from dotenv import load_dotenv
    from fastapi import APIRouter, FastAPI, File, HTTPException, UploadFile
    from fastapi.responses import StreamingResponse, FileResponse
    from fastapi.staticfiles import StaticFiles
    from motor.motor_asyncio import AsyncIOMotorClient
    from pydantic import BaseModel, ConfigDict, Field
    from starlette.middleware.cors import CORSMiddleware

    from seed_data import SEED_AREAS, SEED_MILESTONES, SEED_POSITIONS
    from exports import build_headcount_pdf, build_headcount_xlsx, build_krem_format_xlsx
    from excel_import import parse_headcount_workbook, parse_workbook_rows
except Exception:
    _show_fatal_error(
        "No se pudieron cargar las dependencias del backend:\n\n" + traceback.format_exc()
    )
    raise

load_dotenv(ROOT_DIR / ".env")
logger.info("Archivo .env cargado (si existia) desde %s", ROOT_DIR / ".env")

# Read DB configuration using getenv so defaults or missing values won't raise on import
mongo_url = os.getenv("MONGO_URL")
if not mongo_url:
    logger.warning("MONGO_URL no esta definido en .env; las operaciones de base de datos fallaran.")
client = AsyncIOMotorClient(mongo_url) if mongo_url else None
db = client[os.getenv("DB_NAME")] if client and os.getenv("DB_NAME") else None
if client is not None and not os.getenv("DB_NAME"):
    logger.warning("DB_NAME no esta definido en .env; no se pudo seleccionar la base de datos.")

app = FastAPI(title="KREM Headcount Planner")
api = APIRouter(prefix="/api")

# CORS middleware should be added early so preflight (OPTIONS) requests are handled
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


# ------------------------------ Helpers ----------------------------------

def new_id() -> str:
    return str(uuid.uuid4())


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def strip_id(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


CLASSIFICATIONS = {"DL", "IL", "DLNUN"}
ORIGINS = {"KEMMX", "KOMEX"}
SHIFTS = {"1st", "2nd", "3rd", "N/A"}
MILESTONE_TYPES = {"transfer", "trial_run", "sop", "custom"}
POSITION_STATUSES = {"hired", "vacant", "tbd", "planned", "temp", "transfer"}


# ------------------------------ Models -----------------------------------

class AreaCreate(BaseModel):
    name: str
    code: Optional[str] = None
    description: Optional[str] = ""


class Area(AreaCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)

class LevelCreate(BaseModel):
    name: str
    position_name: Optional[str] = None


class Level(LevelCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class PositionCreate(BaseModel):
    name: str
    area_id: str
    classification: str  # DL | IL | DLNUN
    shift: str = "N/A"
    order: int = 0
    status: str = "planned"
    level: Optional[str] = None
    centro_costos: Optional[str] = None
    # Org chart hierarchy. Named "org_level" (not "level") to avoid clashing
    # with the existing job-level lookup field above, which is unrelated.
    org_level: Optional[int] = None                # 1..7 (1 = top of hierarchy)
    reports_to_position_id: Optional[str] = None


class PositionUpdate(BaseModel):
    name: Optional[str] = None
    area_id: Optional[str] = None
    classification: Optional[str] = None
    shift: Optional[str] = None
    order: Optional[int] = None
    status: Optional[str] = None
    level: Optional[str] = None
    centro_costos: Optional[str] = None
    org_level: Optional[int] = None
    reports_to_position_id: Optional[str] = None


class Position(PositionCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)



class PersonCreate(BaseModel):
    name: str = "TBD"
    position_id: Optional[str] = None
    origin: Optional[str] = None  # KEMMX | KOMEX
    classification: Optional[str] = None
    shift: Optional[str] = None
    hire_date: Optional[str] = None  # ISO date
    status: str = "planned"  # planned | active | training | inactive
    employee_id: Optional[str] = None
    custom_fields: Dict[str, Any] = Field(default_factory=dict)
    notes: Optional[str] = ""
    # Org chart grouping: 1 (top) .. 10 (bottom) within the person's area.
    # Independent from Position.org_level / Position.level (job grade).
    layer: Optional[int] = None


class PersonUpdate(BaseModel):
    name: Optional[str] = None
    position_id: Optional[str] = None
    origin: Optional[str] = None
    classification: Optional[str] = None
    shift: Optional[str] = None
    hire_date: Optional[str] = None
    status: Optional[str] = None
    employee_id: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None
    layer: Optional[int] = None


class Person(PersonCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class MilestoneCreate(BaseModel):
    name: str
    type: str = "custom"  # transfer | trial_run | sop | custom
    date: str  # ISO YYYY-MM-DD
    year: int
    cw: int
    color: Optional[str] = None
    description: Optional[str] = ""


class MilestoneUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    date: Optional[str] = None
    year: Optional[int] = None
    cw: Optional[int] = None
    color: Optional[str] = None
    description: Optional[str] = None


class Milestone(MilestoneCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)


class MilestoneView(Milestone):
    source: str = "legacy"
    phase_id: Optional[str] = None
    phase_name: Optional[str] = None


class PhaseMilestoneInput(BaseModel):
    id: Optional[str] = None
    name: str
    type: str = "custom"
    date: str
    year: int
    cw: int
    description: Optional[str] = ""


class MilestonePhaseCreate(BaseModel):
    name: str
    color: str = "#64748B"
    milestones: List[PhaseMilestoneInput] = Field(default_factory=list)


class MilestonePhaseUpdate(BaseModel):
    name: Optional[str] = None
    color: Optional[str] = None
    milestones: Optional[List[PhaseMilestoneInput]] = None


class MilestonePhase(MilestonePhaseCreate):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    created_at: str = Field(default_factory=now_iso)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    start_year: Optional[int] = None
    start_cw: Optional[int] = None
    end_year: Optional[int] = None
    end_cw: Optional[int] = None


class CellUpdate(BaseModel):
    position_id: str
    year: int
    cw: int
    count: int


class BulkCellUpdate(BaseModel):
    cells: List[CellUpdate]


class CellAssignmentsUpdate(BaseModel):
    position_id: str
    year: int
    cw: int
    person_ids: List[str]


class BulkCellAssignmentsUpdate(BaseModel):
    cells: List[CellAssignmentsUpdate]


# ------------------------------ Areas ------------------------------------

@api.get("/areas", response_model=List[Area])
async def list_areas():
    docs = await db.areas.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    return docs


@api.post("/areas", response_model=Area)
async def create_area(body: AreaCreate):
    a = Area(**body.model_dump())
    await db.areas.insert_one(a.model_dump())
    return a


@api.patch("/areas/{area_id}", response_model=Area)
async def update_area(area_id: str, body: AreaCreate):
    updates = body.model_dump(exclude_none=True)
    res = await db.areas.find_one_and_update(
        {"id": area_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Area not found")
    return strip_id(res)


@api.delete("/areas/{area_id}")
async def delete_area(area_id: str):
    positions = await db.positions.count_documents({"area_id": area_id})
    if positions > 0:
        raise HTTPException(400, f"Area is used by {positions} position(s)")
    result = await db.areas.delete_one({"id": area_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Area not found")
    return {"ok": True}


# ------------------------------ Positions --------------------------------

@api.get("/positions", response_model=List[Position])
async def list_positions():
    docs = await db.positions.find({}, {"_id": 0}).sort([("order", 1), ("name", 1)]).to_list(5000)
    return docs


async def _validate_position_hierarchy(
    pos_id: Optional[str],
    org_level: Optional[int],
    reports_to: Optional[str],
) -> None:
    """Enforce org_level (1-7) and reports_to rules (no self, higher rank = smaller number, no cycles)."""
    if org_level is not None and (org_level < 1 or org_level > 7):
        raise HTTPException(400, "org_level must be between 1 and 7")
    if not reports_to:
        return
    if pos_id and reports_to == pos_id:
        raise HTTPException(400, "A position cannot report to itself")

    target = await db.positions.find_one({"id": reports_to}, {"_id": 0})
    if not target:
        raise HTTPException(400, f"reports_to_position_id {reports_to} does not exist")
    target_org_level = target.get("org_level")
    if org_level is not None and target_org_level is not None:
        if target_org_level >= org_level:
            raise HTTPException(
                400,
                f"reports_to '{target['name']}' has org_level {target_org_level}; "
                f"must be strictly higher rank (smaller number) than {org_level}",
            )
    # Cycle detection: walk up from target and make sure we don't hit pos_id
    if pos_id:
        current = target
        seen = {pos_id}
        for _ in range(30):
            cur_reports = current.get("reports_to_position_id")
            if not cur_reports:
                break
            if cur_reports in seen:
                raise HTTPException(400, "This would create a cycle in the reporting chain")
            seen.add(cur_reports)
            current = await db.positions.find_one({"id": cur_reports}, {"_id": 0})
            if not current:
                break


@api.post("/positions", response_model=Position)
async def create_position(body: PositionCreate):
    if body.classification not in CLASSIFICATIONS:
        raise HTTPException(400, f"classification must be one of {CLASSIFICATIONS}")
    if body.status not in POSITION_STATUSES:
        raise HTTPException(400, f"status must be one of {POSITION_STATUSES}")
    await _validate_position_hierarchy(None, body.org_level, body.reports_to_position_id)
    p = Position(**body.model_dump())
    await db.positions.insert_one(p.model_dump())
    return p


@api.patch("/positions/{position_id}", response_model=Position)
async def update_position(position_id: str, body: PositionUpdate):
    updates = body.model_dump(exclude_none=True)
    if "classification" in updates and updates["classification"] not in CLASSIFICATIONS:
        raise HTTPException(400, f"classification must be one of {CLASSIFICATIONS}")
    if "status" in updates and updates["status"] not in POSITION_STATUSES:
        raise HTTPException(400, f"status must be one of {POSITION_STATUSES}")
    if "org_level" in updates or "reports_to_position_id" in updates:
        current = await db.positions.find_one({"id": position_id}, {"_id": 0})
        if not current:
            raise HTTPException(404, "Position not found")
        merged_org_level = updates.get("org_level", current.get("org_level"))
        merged_report = updates.get("reports_to_position_id", current.get("reports_to_position_id"))
        await _validate_position_hierarchy(position_id, merged_org_level, merged_report)
    res = await db.positions.find_one_and_update(
        {"id": position_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Position not found")
    return strip_id(res)


@api.get("/positions/hierarchy")
async def positions_hierarchy(area_id: Optional[str] = None):
    """Return the org tree as a list of roots, each with recursive `children`."""
    areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    area_by_id = {a["id"]: a for a in areas}

    positions = await db.positions.find({}, {"_id": 0}).sort([("org_level", 1), ("order", 1), ("name", 1)]).to_list(5000)
    people = await db.people.find({"position_id": {"$ne": None}}, {"_id": 0}).to_list(10000)
    person_by_pos: Dict[str, List[dict]] = {}
    for p in people:
        person_by_pos.setdefault(p["position_id"], []).append(p)

    if area_id:
        positions = [p for p in positions if p["area_id"] == area_id]

    pos_by_id = {p["id"]: {**p, "children": [], "assigned": person_by_pos.get(p["id"], [])} for p in positions}
    roots: List[dict] = []
    for p in positions:
        parent = p.get("reports_to_position_id")
        if parent and parent in pos_by_id:
            pos_by_id[parent]["children"].append(pos_by_id[p["id"]])
        else:
            roots.append(pos_by_id[p["id"]])

    def _sort(node):
        node["children"].sort(key=lambda c: (c.get("org_level") or 99, c.get("name") or ""))
        for c in node["children"]:
            _sort(c)
    for r in roots:
        _sort(r)
    roots.sort(key=lambda c: (c.get("org_level") or 99, c.get("name") or ""))

    for pid, node in pos_by_id.items():
        area = area_by_id.get(node["area_id"])
        node["area_name"] = area["name"] if area else "?"
    return {"roots": roots}


@api.delete("/positions/reset")
async def delete_all_positions():
    positions_result = await db.positions.delete_many({})
    headcount_result = await db.headcount_plan.delete_many({})
    people_result = await db.people.update_many({"position_id": {"$ne": None}}, {"$set": {"position_id": None}})
    return {
        "ok": True,
        "positions_deleted": positions_result.deleted_count,
        "headcount_deleted": headcount_result.deleted_count,
        "people_unassigned": people_result.modified_count,
    }


@api.delete("/positions/{position_id}")
async def delete_position(position_id: str):
    await db.headcount_plan.delete_one({"position_id": position_id})
    await db.people.update_many({"position_id": position_id}, {"$set": {"position_id": None}})
    await db.positions.update_many(
        {"reports_to_position_id": position_id}, {"$set": {"reports_to_position_id": None}}
    )
    result = await db.positions.delete_one({"id": position_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Position not found")
    return {"ok": True}


# ------------------------------ People -----------------------------------

@api.get("/people", response_model=List[Person])
async def list_people():
    docs = await db.people.find({}, {"_id": 0}).sort([("status", 1), ("name", 1)]).to_list(10000)
    return docs


def _validate_person_layer(layer: Optional[int]) -> None:
    if layer is not None and (layer < 1 or layer > 10):
        raise HTTPException(400, "layer must be between 1 and 10")


@api.post("/people", response_model=Person)
async def create_person(body: PersonCreate):
    _validate_person_layer(body.layer)
    p = Person(**body.model_dump())
    await db.people.insert_one(p.model_dump())
    return p


@api.patch("/people/{person_id}", response_model=Person)
async def update_person(person_id: str, body: PersonUpdate):
    existing = await db.people.find_one({"id": person_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Person not found")
    updates = body.model_dump(exclude_none=True)
    if "layer" in updates:
        _validate_person_layer(updates["layer"])
    res = await db.people.find_one_and_update(
        {"id": person_id}, {"$set": updates}, return_document=True
    )
    if "position_id" in updates and updates["position_id"] != existing.get("position_id"):
        await _remove_person_from_assignments(person_id)
    return strip_id(res)


@api.delete("/people/{person_id}")
async def delete_person(person_id: str):
    await _remove_person_from_assignments(person_id)
    result = await db.people.delete_one({"id": person_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Person not found")
    return {"ok": True}


@api.get("/people/org-chart")
async def people_org_chart():
    """Org chart data: every area, people grouped by their `layer` (1-10) within it.

    People with no `layer` set land in that area's `unassigned` bucket instead
    of a numbered layer, so nobody silently disappears from the chart.
    """
    areas = await db.areas.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    positions = await db.positions.find({}, {"_id": 0}).to_list(5000)
    pos_by_id = {p["id"]: p for p in positions}
    people = await db.people.find({"position_id": {"$ne": None}}, {"_id": 0}).to_list(10000)

    # area_id -> layer(int)|None -> [people]
    buckets: Dict[str, Dict[Any, List[dict]]] = {}
    for person in people:
        pos = pos_by_id.get(person.get("position_id"))
        if not pos:
            continue
        area_id = pos.get("area_id")
        layer = person.get("layer")
        enriched = {
            **person,
            "position_name": pos.get("name"),
            "classification": pos.get("classification"),
            "centro_costos": pos.get("centro_costos"),
        }
        buckets.setdefault(area_id, {}).setdefault(layer, []).append(enriched)

    result = []
    for area in areas:
        area_id = area["id"]
        layer_map = buckets.get(area_id, {})
        layers = []
        for layer_key in sorted(k for k in layer_map if k is not None):
            layers.append({
                "layer": layer_key,
                "people": sorted(layer_map[layer_key], key=lambda p: p.get("name") or ""),
            })
        unassigned = sorted(layer_map.get(None, []), key=lambda p: p.get("name") or "")
        result.append({
            "area_id": area_id,
            "area_name": area["name"],
            "layers": layers,
            "unassigned": unassigned,
        })
    return {"areas": result}


# ------------------------------ Milestones -------------------------------

def _milestone_sort_key(milestone: dict) -> Tuple[int, int, str, str]:
    return (
        int(milestone.get("year") or 0),
        int(milestone.get("cw") or 0),
        str(milestone.get("date") or ""),
        str(milestone.get("name") or ""),
    )


def _validate_milestone_type(milestone_type: str) -> None:
    if milestone_type not in MILESTONE_TYPES:
        raise HTTPException(400, f"type must be one of {MILESTONE_TYPES}")


def _normalize_phase_milestones(milestones: List[PhaseMilestoneInput]) -> List[dict]:
    normalized = []
    for milestone in milestones:
        _validate_milestone_type(milestone.type)
        normalized.append(
            {
                "id": milestone.id or new_id(),
                "name": milestone.name,
                "type": milestone.type,
                "date": milestone.date,
                "year": milestone.year,
                "cw": milestone.cw,
                "description": milestone.description or "",
            }
        )
    return sorted(normalized, key=_milestone_sort_key)


def _phase_bounds(milestones: List[dict]) -> dict:
    if not milestones:
        return {
            "start_date": None,
            "end_date": None,
            "start_year": None,
            "start_cw": None,
            "end_year": None,
            "end_cw": None,
        }

    ordered = sorted(milestones, key=_milestone_sort_key)
    first = ordered[0]
    last = ordered[-1]
    return {
        "start_date": first["date"],
        "end_date": last["date"],
        "start_year": first["year"],
        "start_cw": first["cw"],
        "end_year": last["year"],
        "end_cw": last["cw"],
    }


def _serialize_phase(doc: dict) -> dict:
    phase = strip_id(dict(doc))
    milestones = sorted(list(phase.get("milestones") or []), key=_milestone_sort_key)
    phase["milestones"] = milestones
    phase.update(_phase_bounds(milestones))
    return phase


def _flatten_phase_milestones(phases: List[dict]) -> List[dict]:
    flattened = []
    for phase in phases:
        for milestone in phase.get("milestones") or []:
            flattened.append(
                {
                    "id": milestone["id"],
                    "name": milestone["name"],
                    "type": milestone["type"],
                    "date": milestone["date"],
                    "year": milestone["year"],
                    "cw": milestone["cw"],
                    "color": phase.get("color"),
                    "description": milestone.get("description") or "",
                    "source": "phase",
                    "phase_id": phase.get("id"),
                    "phase_name": phase.get("name"),
                    "created_at": phase.get("created_at") or now_iso(),
                }
            )
    return flattened


async def _load_legacy_milestones() -> List[dict]:
    docs = await db.milestones.find({}, {"_id": 0}).sort([("year", 1), ("cw", 1)]).to_list(1000)
    legacy = []
    for doc in docs:
        milestone = dict(doc)
        milestone.setdefault("source", "legacy")
        milestone.setdefault("phase_id", None)
        milestone.setdefault("phase_name", None)
        legacy.append(milestone)
    return legacy


async def _load_phases() -> List[dict]:
    docs = await db.milestone_phases.find({}, {"_id": 0}).to_list(1000)
    phases = [_serialize_phase(doc) for doc in docs]
    return sorted(
        phases,
        key=lambda phase: (
            phase.get("start_year") or 9999,
            phase.get("start_cw") or 99,
            phase.get("name") or "",
        ),
    )


async def _load_flattened_milestones() -> List[dict]:
    phases = await _load_phases()
    legacy = await _load_legacy_milestones()
    combined = legacy + _flatten_phase_milestones(phases)
    return sorted(combined, key=_milestone_sort_key)


@api.get("/milestone-phases", response_model=List[MilestonePhase])
async def list_milestone_phases():
    return await _load_phases()


@api.post("/milestone-phases", response_model=MilestonePhase)
async def create_milestone_phase(body: MilestonePhaseCreate):
    milestones = _normalize_phase_milestones(body.milestones)
    phase = MilestonePhase(**body.model_dump(exclude={"milestones"}), milestones=milestones)
    doc = phase.model_dump(exclude={"start_date", "end_date", "start_year", "start_cw", "end_year", "end_cw"})
    await db.milestone_phases.insert_one(doc)
    return _serialize_phase(doc)


@api.patch("/milestone-phases/{phase_id}", response_model=MilestonePhase)
async def update_milestone_phase(phase_id: str, body: MilestonePhaseUpdate):
    existing = await db.milestone_phases.find_one({"id": phase_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Milestone phase not found")

    updates = body.model_dump(exclude_none=True)
    if "milestones" in updates:
        updates["milestones"] = _normalize_phase_milestones([PhaseMilestoneInput(**m) if isinstance(m, dict) else m for m in updates["milestones"]])

    merged = {**existing, **updates}
    await db.milestone_phases.update_one({"id": phase_id}, {"$set": updates})
    return _serialize_phase(merged)


@api.delete("/milestone-phases/{phase_id}")
async def delete_milestone_phase(phase_id: str):
    result = await db.milestone_phases.delete_one({"id": phase_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Milestone phase not found")
    return {"ok": True}


@api.get("/milestones/legacy", response_model=List[Milestone])
async def list_legacy_milestones():
    return await _load_legacy_milestones()

@api.get("/milestones", response_model=List[MilestoneView])
async def list_milestones():
    return await _load_flattened_milestones()


@api.post("/milestones", response_model=Milestone)
async def create_milestone(body: MilestoneCreate):
    _validate_milestone_type(body.type)
    m = Milestone(**body.model_dump())
    await db.milestones.insert_one(m.model_dump())
    return m


@api.patch("/milestones/{milestone_id}", response_model=Milestone)
async def update_milestone(milestone_id: str, body: MilestoneUpdate):
    updates = body.model_dump(exclude_none=True)
    if "type" in updates:
        _validate_milestone_type(updates["type"])
    res = await db.milestones.find_one_and_update(
        {"id": milestone_id}, {"$set": updates}, return_document=True
    )
    if not res:
        raise HTTPException(404, "Milestone not found")
    return strip_id(res)


@api.delete("/milestones/{milestone_id}")
async def delete_milestone(milestone_id: str):
    result = await db.milestones.delete_one({"id": milestone_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Milestone not found")
    return {"ok": True}


# ------------------------------ Headcount Plan ---------------------------

def cell_key(year: int, cw: int) -> str:
    return f"{year}-CW{cw:02d}"


def _planned_cell_count(doc: Optional[dict], key: str) -> int:
    cells = (doc or {}).get("cells") or {}
    value = cells.get(key, 0)
    return value if isinstance(value, int) and value >= 0 else 0


def _assigned_cell_count(doc: Optional[dict], key: str) -> int:
    assignments = (doc or {}).get("assignments") or {}
    assigned_ids = assignments.get(key) or []
    return len(assigned_ids)


def _next_count_from_assignments(doc: Optional[dict], key: str, next_assigned_count: int) -> int:
    current_count = _planned_cell_count(doc, key)
    current_assigned_count = _assigned_cell_count(doc, key)

    # Keep the manual surplus when the cell already represents more planned
    # headcount than the currently named people in that week.
    if current_count > current_assigned_count:
        return max(current_count, next_assigned_count)

    return next_assigned_count


def _validate_manual_cell_count(count: int, assigned_count: int) -> None:
    if count < 0:
        raise HTTPException(400, "count must be >= 0")
    if count < assigned_count:
        raise HTTPException(400, "The planned count cannot be lower than the people assigned to this cell")


async def _remove_person_from_assignments(person_id: str) -> None:
    docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    for doc in docs:
        assignments = dict(doc.get("assignments") or {})
        cells = dict(doc.get("cells") or {})
        changed = False
        for key, assigned_ids in list(assignments.items()):
            if person_id not in assigned_ids:
                continue
            remaining_ids = [assigned_id for assigned_id in assigned_ids if assigned_id != person_id]
            if remaining_ids:
                assignments[key] = remaining_ids
            else:
                assignments.pop(key, None)
            cells[key] = _next_count_from_assignments(doc, key, len(remaining_ids))
            changed = True
        if changed:
            await db.headcount_plan.update_one(
                {"position_id": doc["position_id"]},
                {"$set": {"assignments": assignments, "cells": cells}},
            )


@api.get("/headcount")
async def get_headcount():
    """Return {position_id: {"2025-CW27": count, ...}} for every position."""
    docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    return {d["position_id"]: d.get("cells", {}) for d in docs}


@api.get("/headcount/assignments")
async def get_headcount_assignments():
    docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    return {d["position_id"]: d.get("assignments", {}) for d in docs}


@api.post("/headcount/cell")
async def set_cell(body: CellUpdate):
    key = cell_key(body.year, body.cw)
    existing = await db.headcount_plan.find_one({"position_id": body.position_id}, {"_id": 0, "assignments": 1})
    assigned_count = _assigned_cell_count(existing, key)
    _validate_manual_cell_count(body.count, assigned_count)
    await db.headcount_plan.update_one(
        {"position_id": body.position_id},
        {"$set": {f"cells.{key}": body.count, "position_id": body.position_id}},
        upsert=True,
    )
    return {"ok": True, "position_id": body.position_id, "key": key, "count": body.count}


@api.post("/headcount/bulk")
async def bulk_cells(body: BulkCellUpdate):
    for c in body.cells:
        key = cell_key(c.year, c.cw)
        existing = await db.headcount_plan.find_one({"position_id": c.position_id}, {"_id": 0, "assignments": 1})
        assigned_count = _assigned_cell_count(existing, key)
        _validate_manual_cell_count(c.count, assigned_count)
        await db.headcount_plan.update_one(
            {"position_id": c.position_id},
            {"$set": {f"cells.{key}": c.count, "position_id": c.position_id}},
            upsert=True,
        )
    return {"ok": True, "count": len(body.cells)}


@api.post("/headcount/assignments/cell")
async def set_cell_assignments(body: CellAssignmentsUpdate):
    key = cell_key(body.year, body.cw)
    person_ids = list(dict.fromkeys(body.person_ids))
    existing = await db.headcount_plan.find_one(
        {"position_id": body.position_id},
        {"_id": 0, "assignments": 1, "cells": 1},
    )
    next_count = _next_count_from_assignments(existing, key, len(person_ids))

    if not person_ids:
        await db.headcount_plan.update_one(
            {"position_id": body.position_id},
            {
                "$set": {f"cells.{key}": next_count, "position_id": body.position_id},
                "$unset": {f"assignments.{key}": ""},
            },
            upsert=True,
        )
        return {"ok": True, "position_id": body.position_id, "key": key, "count": next_count, "person_ids": []}

    people_docs = await db.people.find(
        {"id": {"$in": person_ids}, "position_id": body.position_id},
        {"_id": 0, "id": 1},
    ).to_list(len(person_ids))
    valid_ids = {doc["id"] for doc in people_docs}
    if len(valid_ids) != len(person_ids):
        raise HTTPException(400, "All selected people must belong to the same position")

    await db.headcount_plan.update_one(
        {"position_id": body.position_id},
        {
            "$set": {
                f"assignments.{key}": person_ids,
                f"cells.{key}": next_count,
                "position_id": body.position_id,
            },
        },
        upsert=True,
    )
    return {"ok": True, "position_id": body.position_id, "key": key, "count": next_count, "person_ids": person_ids}


@api.post("/headcount/assignments/bulk")
async def set_bulk_cell_assignments(body: BulkCellAssignmentsUpdate):
    grouped: Dict[str, List[CellAssignmentsUpdate]] = {}
    for cell in body.cells:
        grouped.setdefault(cell.position_id, []).append(cell)

    for position_id, cells in grouped.items():
        unique_person_ids = list({person_id for cell in cells for person_id in cell.person_ids})
        if unique_person_ids:
            people_docs = await db.people.find(
                {"id": {"$in": unique_person_ids}, "position_id": position_id},
                {"_id": 0, "id": 1},
            ).to_list(len(unique_person_ids))
            valid_ids = {doc["id"] for doc in people_docs}
            if len(valid_ids) != len(unique_person_ids):
                raise HTTPException(400, "All selected people must belong to the same position")

        existing = await db.headcount_plan.find_one(
            {"position_id": position_id},
            {"_id": 0, "assignments": 1, "cells": 1},
        )
        set_map: Dict[str, Any] = {"position_id": position_id}
        unset_map: Dict[str, str] = {}
        for cell in cells:
            key = cell_key(cell.year, cell.cw)
            person_ids = list(dict.fromkeys(cell.person_ids))
            set_map[f"cells.{key}"] = _next_count_from_assignments(existing, key, len(person_ids))
            if person_ids:
                set_map[f"assignments.{key}"] = person_ids
            else:
                unset_map[f"assignments.{key}"] = ""

        update_doc: Dict[str, Any] = {"$set": set_map}
        if unset_map:
            update_doc["$unset"] = unset_map
        await db.headcount_plan.update_one({"position_id": position_id}, update_doc, upsert=True)

    return {"ok": True, "count": len(body.cells), "positions": len(grouped)}


# ------------------------------ Reports ----------------------------------

async def _load_report_context(year_start: int, cw_start: int, num_weeks: int = 52):
    areas = await db.areas.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    positions = await db.positions.find({}, {"_id": 0}).sort([("order", 1), ("name", 1)]).to_list(5000)
    plan_docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    milestones = await _load_flattened_milestones()
    plan = {d["position_id"]: d.get("cells", {}) for d in plan_docs}
    assignments = {d["position_id"]: d.get("assignments", {}) for d in plan_docs}

    # Compute the list of (year, cw) for the fiscal year range.
    weeks = []
    y, w = year_start, cw_start
    for _ in range(num_weeks):
        weeks.append((y, w))
        w += 1
        if w > 52:
            w = 1
            y += 1
    return areas, positions, plan, assignments, milestones, weeks


@api.get("/reports/headcount.xlsx")
async def export_xlsx(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    areas, positions, plan, assignments, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_headcount_xlsx(areas, positions, plan, assignments, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="headcount_FY{year}.xlsx"'},
    )


@api.get("/reports/headcount.pdf")
async def export_pdf(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    areas, positions, plan, assignments, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_headcount_pdf(areas, positions, plan, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="headcount_FY{year}.pdf"'},
    )


@api.get("/reports/headcount_krem.xlsx")
async def export_krem_xlsx(year: int = 2025, start_cw: int = 27, weeks: int = 52):
    """Excel matching the original KREM template layout, with embedded charts."""
    areas, positions, plan, assignments, milestones, ws = await _load_report_context(year, start_cw, weeks)
    stream = build_krem_format_xlsx(areas, positions, plan, assignments, milestones, ws)
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="KREM_headcount_FY{year}.xlsx"'},
    )


# ------------------------------ Seed / Stats -----------------------------

@api.post("/seed")
async def seed(reset: bool = False):
    """Populate the DB with default KREM plant structure. Idempotent unless reset=True."""
    if reset:
        await db.areas.delete_many({})
        await db.positions.delete_many({})
        await db.milestones.delete_many({})
        await db.headcount_plan.delete_many({})

    area_by_code: Dict[str, str] = {}
    existing_areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    for a in existing_areas:
        area_by_code[a.get("code") or a["name"]] = a["id"]

    for name, code, desc in SEED_AREAS:
        if code in area_by_code:
            continue
        a = Area(name=name, code=code, description=desc)
        await db.areas.insert_one(a.model_dump())
        area_by_code[code] = a.id

    existing_positions = {p["name"] for p in await db.positions.find({}, {"_id": 0}).to_list(5000)}
    for i, (name, area_code, classification, shift) in enumerate(SEED_POSITIONS):
        if name in existing_positions:
            continue
        area_id = area_by_code.get(area_code)
        if not area_id:
            continue
        p = Position(name=name, area_id=area_id, classification=classification, shift=shift, order=i)
        await db.positions.insert_one(p.model_dump())

    existing_ms = {m["name"] for m in await db.milestones.find({}, {"_id": 0}).to_list(1000)}
    for name, mtype, iso_date, y, w, color in SEED_MILESTONES:
        if name in existing_ms:
            continue
        m = Milestone(name=name, type=mtype, date=iso_date, year=y, cw=w, color=color)
        await db.milestones.insert_one(m.model_dump())

    return {"ok": True}


@api.get("/stats")
async def stats():
    areas = await db.areas.count_documents({})
    positions_docs = await db.positions.find({}, {"_id": 0}).to_list(5000)
    positions_total = len(positions_docs)
    by_class: Dict[str, int] = {"DL": 0, "IL": 0, "DLNUN": 0}
    for p in positions_docs:
        by_class[p["classification"]] = by_class.get(p["classification"], 0) + 1

    people_docs = await db.people.find({}, {"_id": 0}).to_list(10000)
    tbd = sum(1 for p in people_docs if (p.get("name") or "").strip().upper() == "TBD")
    assigned = sum(1 for p in people_docs if (p.get("name") or "").strip().upper() != "TBD")

    milestones = len(await _load_flattened_milestones())
    milestone_phases = await db.milestone_phases.count_documents({})

    plan_docs = await db.headcount_plan.find({}, {"_id": 0}).to_list(5000)
    peak = 0
    total_planned = 0
    for d in plan_docs:
        for _, v in (d.get("cells") or {}).items():
            total_planned += int(v)
            if int(v) > peak:
                peak = int(v)

    return {
        "areas": areas,
        "positions_total": positions_total,
        "positions_by_class": by_class,
        "people_total": len(people_docs),
        "people_tbd": tbd,
        "people_assigned": assigned,
        "milestones": milestones,
        "milestone_phases": milestone_phases,
        "planned_total_sum": total_planned,
        "planned_peak_single_cell": peak,
    }


@api.get("/")
async def root():
    return {"service": "KREM Headcount Planner", "time": now_iso()}


# ------------------------------ Excel Import -----------------------------

@api.post("/import/excel")
async def import_excel(
    file: UploadFile = File(...),
    year_start: int = 2025,
    reset_cells: bool = False,
    replace_all: bool = False,
):
    """Import positions and headcount cells from the KREM Excel template.

    - Ensures required areas exist (creates missing ones)
    - Creates missing positions (matched by exact name)
    - Upserts headcount cells (position × CW)
    - If `reset_cells` is true, wipes the whole `headcount_plan` collection first
    - If `replace_all` is true, wipes positions and headcount_plan first
      (keeps areas, people and milestones intact)
    """
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload an .xlsx file")

    contents = await file.read()
    try:
        parsed_positions, parsed_cells = parse_headcount_workbook(contents, year_start=year_start)
    except Exception as e:
        raise HTTPException(400, f"Could not parse workbook: {e}")

    if replace_all:
        await db.positions.delete_many({})
        await db.headcount_plan.delete_many({})

    # 1. Ensure areas exist (create if missing)
    needed_area_codes = {p["area_code"] for p in parsed_positions}
    existing_areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    area_by_code = {a.get("code") or a["name"]: a for a in existing_areas}

    default_area_names = {c: n for n, c, _ in SEED_AREAS}
    for code in needed_area_codes:
        if code not in area_by_code:
            a = Area(name=default_area_names.get(code, code), code=code, description="")
            await db.areas.insert_one(a.model_dump())
            area_by_code[code] = a.model_dump()

    # 2. Ensure positions exist (match by exact name)
    existing_positions = await db.positions.find({}, {"_id": 0}).to_list(5000)
    pos_by_name: Dict[str, dict] = {p["name"]: p for p in existing_positions}

    created_positions = 0
    for pp in parsed_positions:
        if pp["name"] in pos_by_name:
            continue
        area_id = area_by_code[pp["area_code"]]["id"]
        p = Position(
            name=pp["name"],
            area_id=area_id,
            classification=pp["classification"],
            shift=pp["shift"],
            order=len(pos_by_name) + created_positions,
        )
        await db.positions.insert_one(p.model_dump())
        pos_by_name[pp["name"]] = p.model_dump()
        created_positions += 1

    # 3. Reset cells if requested
    if reset_cells:
        await db.headcount_plan.delete_many({})

    # 4. Upsert cells. Group by position to minimise round-trips.
    cells_by_pos: Dict[str, Dict[str, int]] = {}
    for c in parsed_cells:
        pid = pos_by_name[c["position_name"]]["id"]
        key = f"{c['year']}-CW{c['cw']:02d}"
        cells_by_pos.setdefault(pid, {})[key] = c["count"]

    for pid, cells in cells_by_pos.items():
        set_map = {f"cells.{k}": v for k, v in cells.items()}
        set_map["position_id"] = pid
        await db.headcount_plan.update_one(
            {"position_id": pid},
            {"$set": set_map},
            upsert=True,
        )

    return {
        "ok": True,
        "positions_created": created_positions,
        "positions_matched": len(parsed_positions) - created_positions,
        "cells_written": len(parsed_cells),
        "positions_touched": len(cells_by_pos),
        "year_range": sorted({c["year"] for c in parsed_cells}) if parsed_cells else [],
    }


# ------------------------------ Bulk imports (Positions / People) -----------------


@api.post("/positions/import")
async def import_positions(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload an .xlsx file")
    contents = await file.read()
    mapping = {
        "NAME": "name",
        "CLASSIFICATION": "classification",
        "CLASS": "classification",
        "AREA": "area_code",
        "SHIFT": "shift",
        "STATE": "status",
        "LEVEL": "level",
        "CECO": "centro_costos",
        "CENCO": "centro_costos",
        "CENTRO DE COSTOS": "centro_costos",
        "CENTRO COSTOS": "centro_costos",
        "COST CENTER": "centro_costos",
    }
    try:
        rows = parse_workbook_rows(contents, mapping)
    except Exception as e:
        raise HTTPException(400, f"Could not parse workbook: {e}")

    inserted = 0
    errors = 0
    # load existing areas and positions to resolve ids
    existing_areas = await db.areas.find({}, {"_id": 0}).to_list(1000)
    area_by_code = {a.get("code") or a["name"]: a for a in existing_areas}
    existing_positions = {p["name"] for p in await db.positions.find({}, {"_id": 0}).to_list(5000)}

    for r in rows:
        try:
            name = r.get("name")
            if not name:
                errors += 1
                continue
            if name in existing_positions:
                # skip duplicates by exact name
                continue
            area_code = r.get("area_code")
            area_id = None
            if area_code and area_code in area_by_code:
                area_id = area_by_code[area_code]["id"]
            p = Position(
                name=name,
                area_id=area_id or "",
                classification=r.get("classification") or "DL",
                shift=r.get("shift") or "N/A",
                order=0,
                status=r.get("status") or "planned",
                level=r.get("level") or None,
                centro_costos=r.get("centro_costos") or None,
            )
            await db.positions.insert_one(p.model_dump())
            inserted += 1
        except Exception:
            errors += 1

    return {"inserted": inserted, "errors": errors, "message": "Digitalización posiciones completada"}


@api.post("/people/import")
async def import_people(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload an .xlsx file")
    contents = await file.read()
    mapping = {
        "NAME": "name",
        "EMPLOYEE ID": "employee_id",
        "ID": "employee_id",
        "HIRING DATE": "hire_date",
        "HIRING": "hire_date",
        "POSITION": "position_name",
        "CLASS": "classification",
        "CECO": "cenco",
    }
    try:
        rows = parse_workbook_rows(contents, mapping)
    except Exception as e:
        raise HTTPException(400, f"Could not parse workbook: {e}")

    inserted = 0
    errors = 0
    for r in rows:
        try:
            name = r.get("name") or "TBD"
            employee_id = r.get("employee_id")
            # resolve position name to id if possible
            position_id = None
            pname = r.get("position_name")
            if pname:
                pos = await db.positions.find_one({"name": {"$regex": f"^{pname}$", "$options": "i"}}, {"_id": 0})
                if pos:
                    position_id = pos["id"]

            person_doc = Person(
                name=name,
                position_id=position_id,
                origin=None,
                classification=r.get("classification"),
                shift=None,
                hire_date=r.get("hire_date"),
                status="planned",
                employee_id=employee_id,
                custom_fields={"cenco": r.get("cenco")} if r.get("cenco") else {},
                notes="",
            ).model_dump()

            if employee_id:
                # upsert by employee_id to avoid duplicates
                await db.people.update_one({"employee_id": employee_id}, {"$set": person_doc}, upsert=True)
                inserted += 1
            else:
                await db.people.insert_one(person_doc)
                inserted += 1
        except Exception:
            errors += 1

    return {"inserted": inserted, "errors": errors, "message": "Digitalización personas completada"}


# ------------------------------ Levels CRUD -------------------------------


@api.get("/levels", response_model=List[Level])
async def list_levels():
    docs = await db.levels.find({}, {"_id": 0}).sort("name", 1).to_list(1000)
    return docs


@api.post("/levels", response_model=Level)
async def create_level(body: LevelCreate):
    l = Level(**body.model_dump())
    await db.levels.insert_one(l.model_dump())
    return l


@api.post("/levels/import")
async def import_levels(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload an .xlsx file")
    contents = await file.read()
    # mapping: accept both Spanish/English header names
    mapping = {
        "NIVEL": "name",
        "LEVEL": "name",
        "NOMBRE": "name",
        "POSICIÓN": "position_name",
        "POSICION": "position_name",
    }
    try:
        rows = parse_workbook_rows(contents, mapping)
    except Exception as e:
        raise HTTPException(400, f"Could not parse workbook: {e}")

    inserted = 0
    errors = 0
    # fetch existing level names lowercased for dedupe
    existing = await db.levels.find({}, {"_id": 0}).to_list(2000)
    existing_names = set([x.get("name", "").strip().lower() for x in existing if x.get("name")])

    docs_to_insert = []
    seen = set()
    for r in rows:
        try:
            level_val = r.get("name") or r.get("level") or r.get("NIVEL") or r.get("nivel")
            position_val = r.get("position_name")
            if not level_val and not position_val:
                errors += 1
                continue
            name = str(level_val).strip() if level_val else ""
            pos = str(position_val).strip() if position_val else None
            # if level name missing but position provided, use position as level name
            if not name and pos:
                name = pos
            key = name.lower() if name else ""
            if not name:
                errors += 1
                continue
            if key in existing_names or key in seen:
                # if level already exists but we have a position, consider updating existing doc to include position_name if missing
                continue
            seen.add(key)
            l = Level(name=name, position_name=pos)
            docs_to_insert.append(l.model_dump())
        except Exception:
            errors += 1

    if docs_to_insert:
        res = await db.levels.insert_many(docs_to_insert)
        inserted = len(res.inserted_ids) if getattr(res, "inserted_ids", None) is not None else len(docs_to_insert)

    return {"inserted": inserted, "errors": errors, "message": "Digitalización completada: Niveles importados con éxito"}


@api.patch("/levels/{level_id}", response_model=Level)
async def update_level(level_id: str, body: LevelCreate):
    updates = body.model_dump(exclude_none=True)
    res = await db.levels.find_one_and_update({"id": level_id}, {"$set": updates}, return_document=True)
    if not res:
        raise HTTPException(404, "Level not found")
    return strip_id(res)


@api.delete("/levels/{level_id}")
async def delete_level(level_id: str):
    # prevent delete if positions reference the level
    ref_count = await db.positions.count_documents({"level": level_id})
    if ref_count > 0:
        raise HTTPException(400, f"Level is used by {ref_count} position(s)")
    result = await db.levels.delete_one({"id": level_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Level not found")
    return {"ok": True}


# Register API router BEFORE the catch-all so POST routes are matched first
app.include_router(api)

# --- Serve compiled frontend if available (PyInstaller-friendly) -----------------
# The frontend is built with Create React App (via craco), whose build output
# places JS/CSS bundles under "static/" (e.g. /static/js/main.*.js), NOT under
# "assets/" like a Vite build. Mounting at the wrong path here makes every
# request for a bundle fall through to the SPA catch-all below, which returns
# index.html instead of the script -> browser error "Unexpected token '<'"
# (it tries to execute the HTML document as JavaScript).
dist_dir = ROOT_DIR / "dist"
if dist_dir.exists() and dist_dir.is_dir():
    logger.info("Frontend compilado encontrado en %s; se servira junto con la API.", dist_dir)
    static_subdir = dist_dir / "static"
    if static_subdir.exists() and static_subdir.is_dir():
        app.mount("/static", StaticFiles(directory=str(static_subdir)), name="static")
    else:
        logger.warning("No se encontro 'dist/static' en %s; los bundles JS/CSS no cargaran.", dist_dir)

    index_path = dist_dir / "index.html"
    dist_dir_resolved = dist_dir.resolve()

    @app.get("/{full_path:path}")
    async def _serve_react_app(full_path: str):
        # Serve any other top-level build asset directly (favicon.ico,
        # manifest.json, robots.txt, images copied from public/, etc.)
        # before falling back to the SPA's index.html for client-side routes.
        if full_path:
            candidate = (dist_dir / full_path).resolve()
            try:
                candidate.relative_to(dist_dir_resolved)
            except ValueError:
                raise HTTPException(404, "Not found")
            if candidate.is_file():
                return FileResponse(str(candidate))
        if index_path.exists():
            return FileResponse(str(index_path))
        raise HTTPException(404, "Not found")
else:
    logger.warning("No se encontro carpeta 'dist' en %s; solo se serviran las rutas /api.", dist_dir)


@app.on_event("shutdown")
async def _shutdown():
    if client is not None:
        client.close()


if __name__ == "__main__":
    # Real entrypoint used when running the packaged .exe (or `python server.py`
    # directly). Without this block PyInstaller would build an executable that
    # imports the module, defines all the routes... and then exits immediately,
    # because nothing ever calls uvicorn.run(). That was the root cause of the
    # packaged app appearing to "not start": the process launched and closed
    # right away with no visible error (--noconsole has no window to show one).
    import threading
    import time
    import webbrowser

    import uvicorn

    host = os.getenv("APP_HOST", "0.0.0.0")
    try:
        port = int(os.getenv("APP_PORT", "8001"))
    except ValueError:
        logger.warning("APP_PORT invalido en .env, usando 8001 por defecto")
        port = 8001
    display_host = "127.0.0.1" if host in ("0.0.0.0", "") else host
    app_url = f"http://{display_host}:{port}"

    def _open_browser_later() -> None:
        time.sleep(1.5)
        try:
            webbrowser.open(app_url)
        except Exception:
            logger.warning("No se pudo abrir el navegador automaticamente hacia %s", app_url)

    logger.info("Arrancando KREM Headcount Planner en %s (host=%s, port=%s)", app_url, host, port)

    if getattr(sys, "frozen", False):
        # Only auto-open a browser tab for the packaged desktop-style build;
        # in dev mode the developer already controls how they open the app.
        threading.Thread(target=_open_browser_later, daemon=True).start()

    try:
        uvicorn.run(app, host=host, port=port, log_config=None)
    except Exception:
        _show_fatal_error(
            "No se pudo iniciar el servidor KREM Headcount Planner:\n\n" + traceback.format_exc()
        )
        raise
    finally:
        logger.info("Servidor detenido.")
