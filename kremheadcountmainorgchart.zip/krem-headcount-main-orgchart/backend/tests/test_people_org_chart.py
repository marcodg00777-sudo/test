"""Regression tests for the Person `layer` field and GET /api/people/org-chart.

Focus:
- POST/PATCH /api/people accepts `layer` (1-10) and rejects out-of-range values.
- GET /api/people/org-chart groups people by area, then by layer.
- People with no layer land in that area's `unassigned` bucket (not dropped).
- Every area appears in the response, even ones with nobody in them yet.
"""
from __future__ import annotations

import os

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1].rstrip("/")
                break
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def client():
    return requests.Session()


@pytest.fixture(scope="module", autouse=True)
def seeded(client):
    r = client.post(f"{API}/seed", timeout=30)
    assert r.status_code == 200
    yield
    people = client.get(f"{API}/people").json()
    for p in people:
        if p.get("name", "").startswith("TEST_"):
            client.delete(f"{API}/people/{p['id']}")


class TestPersonLayerValidation:
    def test_create_person_with_valid_layer(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/people", json={
            "name": "TEST_Layer_OK", "position_id": pid, "layer": 3
        })
        assert r.status_code == 200, r.text
        assert r.json()["layer"] == 3
        client.delete(f"{API}/people/{r.json()['id']}")

    def test_create_person_layer_out_of_range_rejected(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/people", json={
            "name": "TEST_Layer_Bad", "position_id": pid, "layer": 11
        })
        assert r.status_code == 400

    def test_patch_person_layer(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/people", json={"name": "TEST_Layer_Patch", "position_id": pid})
        person_id = r.json()["id"]
        try:
            r2 = client.patch(f"{API}/people/{person_id}", json={"layer": 7})
            assert r2.status_code == 200
            assert r2.json()["layer"] == 7
            r3 = client.patch(f"{API}/people/{person_id}", json={"layer": 0})
            assert r3.status_code == 400
        finally:
            client.delete(f"{API}/people/{person_id}")


class TestPeopleOrgChart:
    def test_all_areas_present(self, client):
        areas = client.get(f"{API}/areas").json()
        r = client.get(f"{API}/people/org-chart")
        assert r.status_code == 200
        data = r.json()
        assert len(data["areas"]) == len(areas)
        for a in data["areas"]:
            assert "layers" in a and isinstance(a["layers"], list)
            assert "unassigned" in a and isinstance(a["unassigned"], list)

    def test_person_grouped_under_correct_area_and_layer(self, client):
        positions = client.get(f"{API}/positions").json()
        areas = client.get(f"{API}/areas").json()
        pos = positions[0]
        area = next(a for a in areas if a["id"] == pos["area_id"])
        r = client.post(f"{API}/people", json={
            "name": "TEST_OrgChart_Grouped", "position_id": pos["id"], "layer": 5
        })
        person_id = r.json()["id"]
        try:
            data = client.get(f"{API}/people/org-chart").json()
            area_node = next(a for a in data["areas"] if a["area_id"] == area["id"])
            layer5 = next((l for l in area_node["layers"] if l["layer"] == 5), None)
            assert layer5 is not None, "layer 5 bucket missing"
            names = [p["name"] for p in layer5["people"]]
            assert "TEST_OrgChart_Grouped" in names
        finally:
            client.delete(f"{API}/people/{person_id}")

    def test_person_without_layer_goes_to_unassigned(self, client):
        positions = client.get(f"{API}/positions").json()
        areas = client.get(f"{API}/areas").json()
        pos = positions[0]
        area = next(a for a in areas if a["id"] == pos["area_id"])
        r = client.post(f"{API}/people", json={
            "name": "TEST_OrgChart_NoLayer", "position_id": pos["id"]
        })
        person_id = r.json()["id"]
        try:
            data = client.get(f"{API}/people/org-chart").json()
            area_node = next(a for a in data["areas"] if a["area_id"] == area["id"])
            names = [p["name"] for p in area_node["unassigned"]]
            assert "TEST_OrgChart_NoLayer" in names
        finally:
            client.delete(f"{API}/people/{person_id}")
