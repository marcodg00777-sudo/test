"""Generate the KREM Planner desktop icon.

Creates /app/assets/krem-planner.ico with multiple embedded sizes
(16, 32, 48, 64, 128, 256) so Windows picks the right resolution.
"""
from __future__ import annotations

import os
from PIL import Image, ImageDraw, ImageFont

OUT_PATH = os.path.join(os.path.dirname(__file__), "krem-planner.ico")
PNG_PREVIEW = os.path.join(os.path.dirname(__file__), "krem-planner.png")

# Brand palette (matches the web app)
BG_DARK   = (30, 58, 138)   # blue-900  #1E3A8A
BG_MID    = (37, 99, 235)   # blue-600  #2563EB
ACCENT    = (147, 197, 253) # blue-300  #93C5FD  (for the bar chart accent)
WHITE     = (255, 255, 255)


def _find_bold_font(size: int) -> ImageFont.FreeTypeFont:
    """Try a few common bold fonts, fall back to PIL default."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "C:/Windows/Fonts/segoeuib.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_icon(size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Rounded square background using a vertical gradient BG_DARK -> BG_MID
    radius = int(size * 0.22)
    # Create solid rounded rect first
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=BG_DARK)

    # Simulate a subtle gradient by overlaying rounded lines
    for y in range(size):
        # blend factor from 0..1 top->bottom
        t = y / max(1, size - 1)
        r = int(BG_DARK[0] + (BG_MID[0] - BG_DARK[0]) * t)
        g = int(BG_DARK[1] + (BG_MID[1] - BG_DARK[1]) * t)
        b = int(BG_DARK[2] + (BG_MID[2] - BG_DARK[2]) * t)
        d.line([(0, y), (size, y)], fill=(r, g, b))

    # Re-apply rounded mask so gradient stays inside the rounded square
    mask = Image.new("L", (size, size), 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    img.putalpha(mask)

    # Bar-chart accent: 3 small ascending bars in the bottom-right
    bar_w = max(2, size // 22)
    gap = max(1, size // 40)
    base_y = int(size * 0.78)
    bar_heights = [int(size * 0.14), int(size * 0.22), int(size * 0.30)]
    total_w = 3 * bar_w + 2 * gap
    start_x = size - total_w - int(size * 0.16)
    for i, h in enumerate(bar_heights):
        x0 = start_x + i * (bar_w + gap)
        y0 = base_y - h
        y1 = base_y
        d.rounded_rectangle(
            [x0, y0, x0 + bar_w, y1],
            radius=max(1, bar_w // 3),
            fill=ACCENT,
        )

    # Big letter "K" centered-left, bold
    # Slightly smaller for small icon sizes so it stays crisp
    font_size = int(size * (0.68 if size >= 64 else 0.62))
    font = _find_bold_font(font_size)

    text = "K"
    # measure
    bbox = d.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    tx = int(size * 0.16) - bbox[0]
    ty = int((size - th) / 2) - bbox[1] - int(size * 0.02)
    d.text((tx, ty), text, fill=WHITE, font=font)

    return img


def main() -> None:
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    sizes = [16, 24, 32, 48, 64, 128, 256]
    imgs = [draw_icon(s) for s in sizes]
    # Preview PNG (largest)
    imgs[-1].save(PNG_PREVIEW, format="PNG")
    # Multi-resolution ICO — save from the largest, Pillow auto-scales down.
    imgs[-1].save(
        OUT_PATH,
        format="ICO",
        sizes=[(s, s) for s in sizes],
    )
    print(f"Wrote {OUT_PATH}")
    print(f"Wrote {PNG_PREVIEW}")


if __name__ == "__main__":
    main()
