# KREM Plant Headcount Planner — PRD

## Original problem statement
Build a landing page: based on the attached Excel file (KREM plant Headcount planning). The Excel has positions × calendar-week dates, milestones, and staff split by direct (Operators = DL) vs indirect (engineers, chiefs, manager = IL), plus a DLNUN category (Direct Labor Non Union). The user wants a web app to replace Excel input, professional look with primarily blue tones, dashboards & charts, editable milestone dates, adjustable everything, a people database (with TBD for open positions), reports exportable to Excel and PDF, and the option to run locally.

## User choices (confirmed)
- Interface language: **English**
- Auth: **None** (local personal/team use)
- Milestones: **Transfer, Trial Run, SOP** (editable, plus custom type supported)
- Person fields: name/TBD, position, area, shift, origin (KEMMX/KOMEX), classification (DL/IL/DLNUN), hire date + **extensible custom fields**
- Reports: **ONE general report** (like Excel view) exportable to **XLSX + PDF**
- Deployment: cloud + provide code for local install

## Architecture
- **Backend**: FastAPI (`/app/backend/server.py`, seed_data.py, exports.py) + Motor/MongoDB. All routes prefixed with `/api`.
- **Frontend**: React + Tailwind + shadcn/ui + Recharts + lucide-react. Sidebar-driven SPA with routes for Dashboard, Matrix, People, Positions, Milestones, Reports.
- **Exports**: openpyxl for XLSX (frozen headers, milestone-highlighted columns, grand total row), reportlab for PDF (landscape A3).
- **Fonts**: Manrope (headings) + IBM Plex Sans (body) + IBM Plex Mono (data grid).
- **Design system**: Swiss/high-contrast blue-dominant per `/app/design_guidelines.json`. Left-aligned, no gradients on data surfaces.

## Personas
- **Planner / Program Manager**: builds the ramp-up plan, sets milestones, tracks vacancies (TBD).
- **Ops / HR**: fills in real names as recruiting completes; monitors TBD count as a hiring gap KPI.
- **Leadership**: consumes dashboards and downloads the general Excel/PDF report for review meetings.

## Data model (Mongo collections)
- `areas` (id, name, code, description)
- `positions` (id, name, area_id, classification DL|IL|DLNUN, shift, order)
- `people` (id, name|TBD, position_id, origin KEMMX|KOMEX, classification, shift, hire_date, status, employee_id, custom_fields dict, notes)
- `milestones` (id, name, type transfer|trial_run|sop|custom, date, year, cw, color, description)
- `headcount_plan` (position_id, cells: { "YYYY-CWnn": int })

## Implemented (2026-02-16)
- Complete CRUD API for areas, positions, people, milestones, headcount cells (single + bulk)
- Idempotent `/api/seed` loads 10 areas + 56 positions + 3 milestones from the KREM Excel template
- `/api/stats` for dashboard KPIs
- XLSX & PDF export endpoints (general report matching the Excel matrix)
- Dashboard page with 10 KPI cards, weekly stacked bar chart (DL/IL/DLNUN), area pie chart, total-trend line with milestone badges
- Matrix page: Excel-like sticky grid, area collapse, per-week cell edit-on-blur with instant save, milestone-colored columns, class filter, fiscal year selector
- People page with search, status filter, extensible custom-fields form, TBD badges
- Positions page with tabbed Positions / Areas admin
- Milestones page with colored cards and add/edit dialog (ISO CW auto-computed from date)
- Reports page: XLSX + PDF download + local-install instructions
- All interactive elements carry `data-testid` attributes (kebab-case)

## Test results (iteration_1)
- Backend: **18/18 pytest cases pass (100%)**
- Frontend: All critical flows verified via Playwright (Dashboard, Matrix cell save, People CRUD, Positions tabs, Milestones cards, Reports downloads)
- No critical or minor bugs reported

## Backlog / Next Actions
### P1 (nice-to-have, deferred from v1)
- Bulk paste from Excel into Matrix cells (multi-cell edit)
- Snapshot / versioning: freeze a plan as "Baseline" and compare against current
- Plan vs Real overlay: compare planned counts vs actual staffed count (from People)
- Bulk-write optimisation for `/api/headcount/bulk` (use Mongo `bulk_write` with `UpdateOne`)
- Enum validation on People/Position patch (currently only Create enforces)

### P2 (future)
- CSV/XLSX **import** of an existing Excel to populate cells at once
- Per-shift breakdown chart on Dashboard
- Milestone slippage indicator (target date vs actual)
- Multi-plant / multi-scenario support (currently single plant)
- Read-only public share links for reports
