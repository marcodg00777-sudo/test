@echo off
REM ================================================================
REM  KREM Headcount Planner - Create Desktop Shortcut (Windows)
REM  Creates "KREM Planner.lnk" on your desktop pointing at start.bat
REM  with the custom .ico icon assigned.
REM ================================================================
setlocal
cd /d "%~dp0"

set "TARGET=%~dp0start.bat"
set "ICON=%~dp0assets\krem-planner.ico"
set "WORKDIR=%~dp0"
set "SHORTCUT=%USERPROFILE%\Desktop\KREM Planner.lnk"

REM Trim trailing backslash from WORKDIR for a cleaner shortcut
if "%WORKDIR:~-1%"=="\" set "WORKDIR=%WORKDIR:~0,-1%"

if not exist "%TARGET%" (
    echo [ERROR] start.bat not found next to this script.
    pause
    exit /b 1
)
if not exist "%ICON%" (
    echo [ERROR] Icon not found: %ICON%
    echo         Make sure the "assets" folder is next to this script.
    pause
    exit /b 1
)

echo Creating desktop shortcut...
echo   Target : %TARGET%
echo   Icon   : %ICON%
echo   Output : %SHORTCUT%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$s = $ws.CreateShortcut('%SHORTCUT%');" ^
  "$s.TargetPath = '%TARGET%';" ^
  "$s.WorkingDirectory = '%WORKDIR%';" ^
  "$s.IconLocation = '%ICON%,0';" ^
  "$s.Description = 'KREM Plant Headcount Planner';" ^
  "$s.WindowStyle = 1;" ^
  "$s.Save();"

if errorlevel 1 (
    echo [ERROR] Failed to create the shortcut.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Done! Look for "KREM Planner" on your desktop.
echo ============================================
echo.
pause
