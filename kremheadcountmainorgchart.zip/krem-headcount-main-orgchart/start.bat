@echo off
REM ================================================================
REM  KREM Headcount Planner - One-click launcher (Windows)
REM ================================================================
cd /d "%~dp0"

echo.
echo ============================================
echo   Starting KREM Headcount Planner...
echo ============================================
echo.

REM Sanity checks
if not exist backend\.venv (
    echo [ERROR] Python virtual environment not found.
    echo         Run install.bat first.
    pause
    exit /b 1
)
if not exist frontend\node_modules (
    echo [ERROR] Frontend dependencies not installed.
    echo         Run install.bat first.
    pause
    exit /b 1
)

REM Check MongoDB is reachable on 27017
powershell -Command "try { $c=New-Object Net.Sockets.TcpClient('127.0.0.1',27017); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo [WARN] MongoDB is not reachable on port 27017.
    echo        Make sure the MongoDB service is running.
    echo        On Windows: services.msc -^> MongoDB -^> Start
    echo.
    echo Press any key to continue anyway...
    pause >nul
) else (
    echo [OK] MongoDB is running
)

REM Start backend in a new window
echo Launching backend (port 8001)...
start "KREM Backend" cmd /k "cd /d %~dp0backend && .venv\Scripts\activate.bat && uvicorn server:app --host 0.0.0.0 --port 8001 --reload"

REM Small delay so backend has time to bind the port
timeout /t 4 /nobreak >nul

REM Start frontend in a new window
echo Launching frontend (port 3000)...
start "KREM Frontend" cmd /k "cd /d %~dp0frontend && yarn start"

REM Wait then open the browser
timeout /t 8 /nobreak >nul
start "" "http://localhost:3000"

echo.
echo ============================================
echo   Running!
echo ============================================
echo   Backend:  http://localhost:8001/api/
echo   Frontend: http://localhost:3000
echo.
echo Two console windows have been opened for the
echo backend and frontend. Close them to stop the app.
echo ============================================
echo.
pause
