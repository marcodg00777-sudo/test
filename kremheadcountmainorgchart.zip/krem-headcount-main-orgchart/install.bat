@echo off
REM ================================================================
REM  KREM Headcount Planner - First-time installer (Windows)
REM ================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================
echo   KREM Headcount Planner - Local Installer
echo ============================================
echo.

REM ----- Check Python
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo         Download Python 3.11+ from https://www.python.org/downloads/
    echo         Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [OK] Python !PYVER! found

REM ----- Check Node
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo         Download Node 20+ from https://nodejs.org/
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do set NODEVER=%%v
echo [OK] Node !NODEVER! found

REM ----- Check Yarn
where yarn >nul 2>&1
if errorlevel 1 (
    echo [INFO] Yarn not found. Installing via npm...
    call npm install -g yarn
    if errorlevel 1 (
        echo [ERROR] Could not install yarn. Try running: npm install -g yarn
        pause
        exit /b 1
    )
)
echo [OK] Yarn ready

REM ----- Check MongoDB (best effort - not blocking)
where mongod >nul 2>&1
if errorlevel 1 (
    echo [WARN] MongoDB "mongod" is not in PATH.
    echo        Make sure MongoDB is installed and running as a service.
    echo        Download: https://www.mongodb.com/try/download/community
    echo        The app will not work without MongoDB.
    echo.
    echo Press any key to continue anyway...
    pause >nul
) else (
    echo [OK] MongoDB CLI detected
)

echo.
echo --------------------------------------------
echo   Backend setup
echo --------------------------------------------
cd backend
if not exist .venv (
    echo Creating Python virtual environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat
echo Installing Python dependencies (this can take a couple of minutes)...
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Backend dependency install failed.
    pause
    exit /b 1
)

if not exist .env (
    echo Creating backend/.env with defaults...
    (
        echo MONGO_URL=mongodb://localhost:27017
        echo DB_NAME=krem_headcount
        echo CORS_ORIGINS=*
    ) > .env
    echo [OK] backend/.env created
) else (
    echo [OK] backend/.env already exists - keeping it
)
call .venv\Scripts\deactivate.bat
cd ..

echo.
echo --------------------------------------------
echo   Frontend setup
echo --------------------------------------------
cd frontend
if not exist .env (
    echo Creating frontend/.env with defaults...
    (
        echo REACT_APP_BACKEND_URL=http://localhost:8001
        echo WDS_SOCKET_PORT=0
    ) > .env
    echo [OK] frontend/.env created
) else (
    echo [OK] frontend/.env already exists - keeping it
)

echo Installing frontend dependencies (this can take several minutes)...
call yarn install
if errorlevel 1 (
    echo [ERROR] Frontend install failed.
    pause
    exit /b 1
)
cd ..

echo.
echo ============================================
echo   Install complete!
echo ============================================
echo.
echo Next step: double-click "start.bat" to launch the app.
echo.
pause
