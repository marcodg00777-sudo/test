import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Users,
  UserX,
  Briefcase,
  Layers,
  Sparkles,
  Upload,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  BarChart,
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  CartesianGrid,
  LineChart,
  Line,
  ReferenceLine,
} from "recharts";

import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import { generateFiscalYear } from "@/lib/cw";

const CLASS_COLORS = { DL: "#0284C7", IL: "#4F46E5", DLNUN: "#EA580C" };
const AREA_PALETTE = ["#1E40AF", "#3B82F6", "#0284C7", "#0EA5E9", "#4F46E5", "#6366F1", "#8B5CF6", "#EA580C", "#F59E0B", "#10B981"];

function TrendTooltip({ active, label, payload, milestonesByWeek }) {
  if (!active || !payload?.length) return null;

  const milestones = milestonesByWeek[label] || [];

  return (
    <div className="rounded-md border border-slate-200 bg-white px-3 py-2 text-xs shadow-sm">
      <div className="font-semibold text-slate-900">{label}</div>
      <div className="mt-1 text-slate-700">Total: {payload[0]?.value ?? 0}</div>
      {milestones.length > 0 && (
        <div className="mt-2 space-y-1">
          {milestones.map((milestone) => (
            <div key={milestone.id} className="flex items-center gap-2 text-slate-700">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: milestone.color || "#64748b" }} />
              <span>{milestone.name}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [positions, setPositions] = useState([]);
  const [areas, setAreas] = useState([]);
  const [plan, setPlan] = useState({});
  const [milestones, setMilestones] = useState([]);
  const [seeding, setSeeding] = useState(false);
  const [importing, setImporting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [pendingFile, setPendingFile] = useState(null);
  const fileInputRef = useRef(null);
  const [selectedYear, setSelectedYear] = useState(2026);

  async function load() {
    setLoading(true);
    try {
      const [s, p, a, hc, ms] = await Promise.all([
        api.get(endpoints.stats),
        api.get(endpoints.positions),
        api.get(endpoints.areas),
        api.get(endpoints.headcount),
        api.get(endpoints.milestones),
      ]);
      setStats(s.data);
      setPositions(p.data);
      setAreas(a.data);
      setPlan(hc.data);
      setMilestones(ms.data);
    } catch (e) {
      toast.error("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  useEffect(() => {
    function refreshWhenVisible() {
      if (document.visibilityState === "visible") load();
    }

    window.addEventListener("focus", load);
    document.addEventListener("visibilitychange", refreshWhenVisible);
    return () => {
      window.removeEventListener("focus", load);
      document.removeEventListener("visibilitychange", refreshWhenVisible);
    };
  }, []);

  const availableYears = useMemo(() => {
    const years = new Set();

    Object.values(plan).forEach((cells) => {
      Object.keys(cells || {}).forEach((key) => {
        const year = parseInt(String(key).split("-CW")[0], 10);
        if (!Number.isNaN(year) && year >= 2026) years.add(year);
      });
    });

    milestones.forEach((milestone) => {
      if (milestone.year >= 2026) years.add(milestone.year);
    });

    const ordered = Array.from(years).sort((a, b) => a - b);
    return ordered.length > 0 ? ordered : [2026, 2027];
  }, [milestones, plan]);

  useEffect(() => {
    if (!availableYears.includes(selectedYear)) {
      setSelectedYear(availableYears[0]);
    }
  }, [availableYears, selectedYear]);

  const weeks = useMemo(() => generateFiscalYear(selectedYear, 27, 52), [selectedYear]);

  async function handleSeed() {
    setSeeding(true);
    try {
      await api.post(endpoints.seed);
      toast.success("Default KREM structure loaded");
      await load();
    } catch {
      toast.error("Seeding failed");
    } finally {
      setSeeding(false);
    }
  }

  async function handleImportFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPendingFile(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function runImport(replaceAll) {
    if (!pendingFile) return;
    setImporting(true);
    try {
      const fd = new FormData();
      fd.append("file", pendingFile);
      const qs = `year_start=2025&replace_all=${replaceAll ? "true" : "false"}&reset_cells=${replaceAll ? "true" : "false"}`;
      const res = await api.post(`/import/excel?${qs}`, fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      const { positions_created, positions_matched, cells_written, year_range } = res.data;
      toast.success(
        `Imported ${cells_written} cells · ${positions_created} new · ${positions_matched} matched · years ${year_range.join(", ")}`,
        { duration: 6000 }
      );
      await load();
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Import failed");
    } finally {
      setImporting(false);
      setPendingFile(null);
    }
  }

  // Build chart data
  const weeklyStack = weeks.map((w) => {
    const row = { name: w.label, DL: 0, IL: 0, DLNUN: 0 };
    positions.forEach((p) => {
      const v = plan[p.id]?.[w.key] || 0;
      row[p.classification] = (row[p.classification] || 0) + v;
    });
    return row;
  });

  const areaTotals = areas.map((a, i) => {
    let total = 0;
    positions.filter((p) => p.area_id === a.id).forEach((p) => {
      weeks.forEach((week) => {
        total += plan[p.id]?.[week.key] || 0;
      });
    });
    return { name: a.name, value: total, fill: AREA_PALETTE[i % AREA_PALETTE.length] };
  }).filter((r) => r.value > 0);

  const totalTrend = weeks.map((w) => {
    const total = positions.reduce((acc, p) => acc + (plan[p.id]?.[w.key] || 0), 0);
    return { name: w.label, total };
  });

  const visibleMilestones = milestones.filter((m) => weeks.some((w) => w.year === m.year && w.cw === m.cw));
  const milestonesByWeek = useMemo(() => visibleMilestones.reduce((acc, milestone) => {
    const key = `CW${String(milestone.cw).padStart(2, "0")}`;
    if (!acc[key]) acc[key] = [];
    acc[key].push(milestone);
    return acc;
  }, {}), [visibleMilestones]);

  const isEmpty = !loading && stats && stats.positions_total === 0;

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle="Overview of headcount planning progress"
        testId="dashboard-header"
        actions={
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              accept=".xlsx,.xlsm"
              className="hidden"
              onChange={handleImportFile}
              data-testid="import-file-input"
            />
            <Button
              data-testid="import-excel-btn"
              onClick={() => fileInputRef.current?.click()}
              disabled={importing}
              variant="outline"
              className="border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <Upload className="w-4 h-4 mr-2" />
              {importing ? "Importing…" : "Import from Excel"}
            </Button>
            <Button
              data-testid="seed-btn"
              onClick={handleSeed}
              disabled={seeding}
              variant="outline"
              className="border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              {seeding ? "Loading…" : "Load KREM defaults"}
            </Button>
          </div>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-6">
        {isEmpty && (
          <div className="rounded-md border border-blue-200 bg-blue-50 p-6" data-testid="empty-onboarding">
            <h2 className="font-heading font-bold text-lg text-blue-900 mb-1">Welcome to KREM Planner</h2>
            <p className="text-sm text-slate-700 mb-3">
              No positions loaded yet. Click <b>Load KREM defaults</b> to preload areas, positions and milestones based on your Excel template.
            </p>
          </div>
        )}

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard testId="kpi-areas"     label="Areas"      value={stats?.areas ?? "—"}            icon={Layers}   accent="blue" />
          <StatCard testId="kpi-positions" label="Positions"  value={stats?.positions_total ?? "—"}  icon={Briefcase} accent="indigo" />
          <StatCard testId="kpi-dl"        label="DL"         value={stats?.positions_by_class?.DL ?? 0}   accent="blue" />
          <StatCard testId="kpi-il"        label="IL"         value={stats?.positions_by_class?.IL ?? 0}   accent="indigo" />
          <StatCard testId="kpi-dlnun"     label="DLNUN"      value={stats?.positions_by_class?.DLNUN ?? 0} accent="orange" />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-2 gap-4">
          <StatCard testId="kpi-people-total"    label="People (all)"       value={stats?.people_total ?? 0} icon={Users} />
          <StatCard testId="kpi-people-tbd"      label="TBD (open)"         value={stats?.people_tbd ?? 0}    icon={UserX} accent="orange" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-md p-5" data-testid="chart-weekly-stack">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-overline">Headcount by week</div>
                <h3 className="font-heading font-semibold text-base text-slate-900 mt-0.5">Weekly plan (DL / IL / DLNUN)</h3>
              </div>
              <Select value={String(selectedYear)} onValueChange={(value) => setSelectedYear(parseInt(value, 10))}>
                <SelectTrigger className="w-[120px] h-9" data-testid="dashboard-year-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableYears.map((year) => (
                    <SelectItem key={year} value={String(year)}>FY {year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="h-72">
              {weeklyStack.every((row) => row.DL === 0 && row.IL === 0 && row.DLNUN === 0) ? (
                <div className="h-full flex items-center justify-center text-sm text-slate-400">
                  No hay headcount cargado para FY {selectedYear}.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyStack} margin={{ top: 5, right: 8, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={3} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="DL" stackId="a" fill={CLASS_COLORS.DL} />
                    <Bar dataKey="IL" stackId="a" fill={CLASS_COLORS.IL} />
                    <Bar dataKey="DLNUN" stackId="a" fill={CLASS_COLORS.DLNUN} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-md p-5" data-testid="chart-area-pareto">
            <div className="text-overline">Distribution</div>
            <h3 className="font-heading font-semibold text-base text-slate-900 mt-0.5 mb-3">Pareto by area</h3>
            <div className="h-72">
              {areaTotals.length === 0 ? (
                <div className="h-full flex items-center justify-center text-sm text-slate-400">No hay datos para FY {selectedYear}.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={areaTotals
                    .slice()
                    .sort((a, b) => b.value - a.value)
                    .map((entry, index, list) => {
                      const total = list.reduce((sum, item) => sum + item.value, 0) || 1;
                      const running = list.slice(0, index + 1).reduce((sum, item) => sum + item.value, 0);
                      return { ...entry, cumulative: Math.round((running / total) * 100) };
                    })} margin={{ top: 5, right: 8, left: -20, bottom: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-20} textAnchor="end" height={55} interval={0} />
                    <YAxis yAxisId="left" tick={{ fontSize: 10 }} />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tickFormatter={(value) => `${value}%`} tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar yAxisId="left" dataKey="value" name="Total" fill="#1E40AF" radius={[4, 4, 0, 0]} />
                    <Line yAxisId="right" type="monotone" dataKey="cumulative" name="Acumulado" stroke="#EA580C" strokeWidth={2} dot={{ r: 2 }} />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-md p-5" data-testid="chart-total-trend">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-overline">Ramp-up</div>
              <h3 className="font-heading font-semibold text-base text-slate-900 mt-0.5">Total plant headcount trend</h3>
            </div>
          </div>
          <div className="h-72">
            {totalTrend.every((row) => row.total === 0) ? (
              <div className="h-full flex items-center justify-center text-sm text-slate-400">
                No hay datos para la tendencia de FY {selectedYear}.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={totalTrend} margin={{ top: 5, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={3} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip content={<TrendTooltip milestonesByWeek={milestonesByWeek} />} />
                  {visibleMilestones.map((milestone) => (
                    <ReferenceLine
                      key={milestone.id}
                      x={`CW${String(milestone.cw).padStart(2, "0")}`}
                      stroke={milestone.color || "#64748b"}
                      strokeWidth={2}
                      strokeDasharray="4 4"
                      ifOverflow="extendDomain"
                    />
                  ))}
                  <Line type="monotone" dataKey="total" stroke="#1E40AF" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      <AlertDialog open={!!pendingFile} onOpenChange={(o) => { if (!o) setPendingFile(null); }}>
        <AlertDialogContent data-testid="import-confirm-dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>Import &quot;{pendingFile?.name}&quot;</AlertDialogTitle>
            <AlertDialogDescription>
              Choose how to apply the workbook data:
              <br /><br />
              <b>Replace all</b> — wipes existing positions &amp; planning cells, then imports fresh from the Excel. Areas, people and milestones are preserved.
              <br /><br />
              <b>Merge</b> — keeps existing positions, adds new ones from the Excel and upserts the cells that appear in the workbook.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="import-cancel-btn">Cancel</AlertDialogCancel>
            <AlertDialogAction
              data-testid="import-merge-btn"
              onClick={() => runImport(false)}
              className="bg-blue-700 hover:bg-blue-800"
            >
              Merge
            </AlertDialogAction>
            <AlertDialogAction
              data-testid="import-replace-btn"
              onClick={() => runImport(true)}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Replace all
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
