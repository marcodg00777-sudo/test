import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ChevronDown, ChevronRight, Flag, Pencil, Plus, Trash2 } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import { isoWeekOfDate } from "@/lib/cw";

const TYPES = [
  { value: "transfer", label: "Transfer", color: "#8B5CF6" },
  { value: "trial_run", label: "Trial Run", color: "#EAB308" },
  { value: "sop", label: "SOP", color: "#10B981" },
  { value: "custom", label: "Custom", color: "#64748B" },
];

function emptyPhaseMilestone(type = "transfer") {
  const selectedType = TYPES.find((item) => item.value === type) || TYPES[0];
  return {
    id: undefined,
    name: selectedType.label,
    type: selectedType.value,
    date: "",
    description: "",
  };
}

function emptyPhaseForm() {
  return {
    name: "Nueva fase",
    color: "#8B5CF6",
    milestones: [emptyPhaseMilestone()],
  };
}

function formatPhaseRange(phase) {
  if (!phase?.start_date || !phase?.end_date) return "Sin fechas";
  if (phase.start_date === phase.end_date) return phase.start_date;
  return `${phase.start_date} al ${phase.end_date}`;
}

export default function MilestonesPage() {
  const [phases, setPhases] = useState([]);
  const [legacyMilestones, setLegacyMilestones] = useState([]);
  const [phaseDialog, setPhaseDialog] = useState(false);
  const [legacyDialog, setLegacyDialog] = useState(false);
  const [editingPhase, setEditingPhase] = useState(null);
  const [editingLegacy, setEditingLegacy] = useState(null);
  const [phaseForm, setPhaseForm] = useState(emptyPhaseForm());
  const [legacyForm, setLegacyForm] = useState({ name: "", type: "transfer", date: "", color: "#8B5CF6", description: "" });
  const [collapsedPhases, setCollapsedPhases] = useState({});

  function isBackendPhaseRouteMissing(error) {
    const status = error?.response?.status;
    return status === 404 || status === 405;
  }

  const load = useCallback(async () => {
    try {
      const [phaseResponse, legacyResponse] = await Promise.all([
        api.get(endpoints.milestonePhases).catch((error) => {
          if (isBackendPhaseRouteMissing(error)) return { data: [] };
          throw error;
        }),
        api.get(endpoints.legacyMilestones).catch(async (error) => {
          if (isBackendPhaseRouteMissing(error)) {
            const fallback = await api.get(endpoints.milestones);
            return { data: fallback.data.filter((milestone) => milestone.source !== "phase") };
          }
          throw error;
        }),
      ]);
      setPhases(phaseResponse.data);
      setLegacyMilestones(legacyResponse.data);
    } catch (error) {
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudieron cargar las fases.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const totalNestedMilestones = useMemo(
    () => phases.reduce((sum, phase) => sum + (phase.milestones?.length || 0), 0),
    [phases]
  );

  function openCreatePhase() {
    setEditingPhase(null);
    setPhaseForm(emptyPhaseForm());
    setPhaseDialog(true);
  }

  function openEditPhase(phase) {
    setEditingPhase(phase);
    setPhaseForm({
      name: phase.name,
      color: phase.color || "#64748B",
      milestones: (phase.milestones || []).map((milestone) => ({
        id: milestone.id,
        name: milestone.name,
        type: milestone.type,
        date: milestone.date,
        description: milestone.description || "",
      })),
    });
    setPhaseDialog(true);
  }

  function openLegacyEdit(milestone) {
    setEditingLegacy(milestone);
    setLegacyForm({
      name: milestone.name,
      type: milestone.type,
      date: milestone.date,
      color: milestone.color || "#64748B",
      description: milestone.description || "",
    });
    setLegacyDialog(true);
  }

  function updatePhaseMilestone(index, field, value) {
    setPhaseForm((prev) => {
      const milestones = prev.milestones.map((milestone, milestoneIndex) => {
        if (milestoneIndex !== index) return milestone;
        const next = { ...milestone, [field]: value };
        if (field === "type") {
          const selectedType = TYPES.find((item) => item.value === value);
          if (selectedType && (!milestone.name || milestone.name === (TYPES.find((item) => item.value === milestone.type)?.label || milestone.name))) {
            next.name = selectedType.label;
          }
        }
        return next;
      });
      return { ...prev, milestones };
    });
  }

  function addPhaseMilestone() {
    setPhaseForm((prev) => ({
      ...prev,
      milestones: [...prev.milestones, emptyPhaseMilestone("custom")],
    }));
  }

  function removePhaseMilestone(index) {
    setPhaseForm((prev) => {
      const milestones = prev.milestones.filter((_, milestoneIndex) => milestoneIndex !== index);
      return { ...prev, milestones: milestones.length > 0 ? milestones : [emptyPhaseMilestone()] };
    });
  }

  async function submitPhase(event) {
    event.preventDefault();

    const milestones = [];
    for (const milestone of phaseForm.milestones) {
      if (!milestone.name.trim() || !milestone.date) {
        toast.error("Digitalizacion: completa nombre y fecha en cada milestone de la fase.");
        return;
      }
      const { year, cw } = isoWeekOfDate(milestone.date);
      milestones.push({
        id: milestone.id,
        name: milestone.name,
        type: milestone.type,
        date: milestone.date,
        year,
        cw,
        description: milestone.description || "",
      });
    }

    const payload = {
      name: phaseForm.name,
      color: phaseForm.color,
      milestones,
    };

    try {
      if (editingPhase) {
        await api.patch(`${endpoints.milestonePhases}/${editingPhase.id}`, payload);
        toast.success("Digitalizacion: fase actualizada.");
      } else {
        await api.post(endpoints.milestonePhases, payload);
        toast.success("Digitalizacion: fase creada.");
      }
      setPhaseDialog(false);
      await load();
    } catch (error) {
      if (isBackendPhaseRouteMissing(error)) {
        toast.error("Digitalizacion: reinicia el backend para habilitar phases.");
        return;
      }
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo guardar la fase.");
    }
  }

  async function submitLegacy(event) {
    event.preventDefault();
    if (!legacyForm.date) {
      toast.error("Digitalizacion: selecciona una fecha.");
      return;
    }

    const { year, cw } = isoWeekOfDate(legacyForm.date);
    const payload = { ...legacyForm, year, cw };
    try {
      await api.patch(`${endpoints.milestones}/${editingLegacy.id}`, payload);
      toast.success("Digitalizacion: milestone existente actualizado.");
      setLegacyDialog(false);
      await load();
    } catch (error) {
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo guardar el milestone existente.");
    }
  }

  async function removePhase(phase) {
    if (!confirm(`Eliminar la fase ${phase.name}?`)) return;
    try {
      await api.delete(`${endpoints.milestonePhases}/${phase.id}`);
      toast.success("Digitalizacion: fase eliminada.");
      await load();
    } catch (error) {
      if (isBackendPhaseRouteMissing(error)) {
        toast.error("Digitalizacion: reinicia el backend para habilitar phases.");
        return;
      }
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo eliminar la fase.");
    }
  }

  async function removeLegacy(milestone) {
    if (!confirm(`Eliminar el milestone ${milestone.name}?`)) return;
    try {
      await api.delete(`${endpoints.milestones}/${milestone.id}`);
      toast.success("Digitalizacion: milestone existente eliminado.");
      await load();
    } catch (error) {
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo eliminar el milestone existente.");
    }
  }

  return (
    <>
      <PageHeader
        title="Milestones"
        subtitle="Crea phases con milestones internos sin afectar los marcadores que ya existen en Matrix y Dashboard."
        testId="milestones-header"
        actions={
          <Button data-testid="add-phase-btn" onClick={openCreatePhase} className="bg-blue-700 hover:bg-blue-800">
            <Plus className="w-4 h-4 mr-1" /> Add Phase
          </Button>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-md border border-slate-200 bg-white p-4">
            <div className="text-xs text-slate-500">Fases</div>
            <div className="mt-2 text-2xl font-heading font-bold text-slate-900">{phases.length}</div>
          </div>
          <div className="rounded-md border border-slate-200 bg-white p-4">
            <div className="text-xs text-slate-500">Milestones dentro de phases</div>
            <div className="mt-2 text-2xl font-heading font-bold text-slate-900">{totalNestedMilestones}</div>
          </div>
          <div className="rounded-md border border-slate-200 bg-white p-4">
            <div className="text-xs text-slate-500">Milestones existentes</div>
            <div className="mt-2 text-2xl font-heading font-bold text-slate-900">{legacyMilestones.length}</div>
          </div>
        </div>

        <section className="space-y-4">
          <div>
            <div className="text-overline">Phases</div>
            <h2 className="font-heading text-lg font-semibold text-slate-900">Fases con milestones</h2>
            <p className="text-sm text-slate-500">La fase dura desde el primer milestone hasta el ultimo. Matrix, Dashboard y reportes toman esos milestones sin borrar nada de lo existente.</p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {phases.length === 0 && (
              <div className="col-span-full text-center py-14 border border-dashed border-slate-300 rounded-md bg-white" data-testid="phases-empty">
                <Flag className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <div className="text-sm text-slate-500">Todavia no hay phases. Crea la primera para agrupar milestones.</div>
              </div>
            )}

            {phases.map((phase) => (
              <div key={phase.id} className="rounded-md border border-slate-200 bg-white overflow-hidden" data-testid={`phase-card-${phase.id}`}>
                <div className="h-2" style={{ backgroundColor: phase.color || "#64748B" }} />
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => setCollapsedPhases((prev) => ({ ...prev, [phase.id]: !prev[phase.id] }))}
                      className="flex items-start gap-3 text-left"
                    >
                      <span className="mt-1 text-slate-500">
                        {collapsedPhases[phase.id] ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </span>
                      <div>
                        <div className="text-overline">Phase</div>
                        <h3 className="font-heading text-lg font-bold text-slate-900">{phase.name}</h3>
                        <div className="mt-1 text-sm text-slate-500">{formatPhaseRange(phase)}</div>
                        {phase.start_cw && phase.end_cw && (
                          <div className="text-xs text-slate-500 mt-1">
                            CW{String(phase.start_cw).padStart(2, "0")} {phase.start_year} hasta CW{String(phase.end_cw).padStart(2, "0")} {phase.end_year}
                          </div>
                        )}
                      </div>
                    </button>
                    <div className="flex items-center gap-2">
                      <Button type="button" size="sm" variant="outline" onClick={() => openEditPhase(phase)}>
                        <Pencil className="w-4 h-4 mr-1" /> Edit
                      </Button>
                      <Button type="button" size="sm" variant="outline" onClick={() => removePhase(phase)} className="text-red-600 border-red-200 hover:bg-red-50">
                        <Trash2 className="w-4 h-4 mr-1" /> Delete
                      </Button>
                    </div>
                  </div>

                  {!collapsedPhases[phase.id] && (
                    <div className="space-y-3">
                      {(phase.milestones || []).map((milestone) => (
                        <div key={milestone.id} className="rounded-md border border-slate-200 bg-slate-50 px-4 py-3">
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              <div className="text-xs uppercase tracking-wide text-slate-500">{milestone.type.replace("_", " ")}</div>
                              <div className="font-medium text-slate-900">{milestone.name}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-mono text-sm text-slate-900">{milestone.date}</div>
                              <div className="text-xs text-slate-500">CW{String(milestone.cw).padStart(2, "0")} · {milestone.year}</div>
                            </div>
                          </div>
                          {milestone.description && <div className="mt-2 text-sm text-slate-500">{milestone.description}</div>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div>
            <div className="text-overline">Compatibilidad</div>
            <h2 className="font-heading text-lg font-semibold text-slate-900">Milestones existentes</h2>
            <p className="text-sm text-slate-500">Estos marcadores ya viven en la base actual. Se siguen usando en Matrix, Dashboard y reportes hasta que decidas recrearlos dentro de una phase.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {legacyMilestones.length === 0 && (
              <div className="col-span-full rounded-md border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
                No hay milestones existentes fuera de phases.
              </div>
            )}

            {legacyMilestones.map((milestone) => (
              <button
                key={milestone.id}
                type="button"
                onClick={() => openLegacyEdit(milestone)}
                data-testid={`legacy-milestone-card-${milestone.id}`}
                className="text-left bg-white border border-slate-200 rounded-md p-5 hover:-translate-y-[1px] transition-transform duration-150 relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-1.5 h-full" style={{ backgroundColor: milestone.color || "#64748B" }} />
                <div className="flex items-start justify-between gap-3">
                  <div className="pl-2">
                    <div className="text-overline">Milestone existente</div>
                    <h3 className="font-heading font-bold text-lg text-slate-900">{milestone.name}</h3>
                    <div className="text-2xl font-mono font-semibold text-slate-800 mt-1">{milestone.date}</div>
                    <div className="text-xs text-slate-500 mt-1">CW{String(milestone.cw).padStart(2, "0")} · {milestone.year}</div>
                    {milestone.description && <div className="text-sm text-slate-500 mt-2">{milestone.description}</div>}
                  </div>
                  <button
                    type="button"
                    onClick={(event) => { event.stopPropagation(); removeLegacy(milestone); }}
                    className="text-slate-300 hover:text-red-600 transition-colors duration-150"
                    data-testid={`delete-legacy-milestone-${milestone.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      <Dialog open={phaseDialog} onOpenChange={setPhaseDialog}>
        <DialogContent className="max-w-4xl" data-testid="phase-dialog">
          <DialogHeader>
            <DialogTitle>{editingPhase ? "Edit phase" : "Add phase"}</DialogTitle>
            <DialogDescription>Define el nombre, color y milestones que marcan el inicio y cierre de la fase.</DialogDescription>
          </DialogHeader>

          <form onSubmit={submitPhase} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Nombre de la fase</Label>
                <Input value={phaseForm.name} onChange={(event) => setPhaseForm({ ...phaseForm, name: event.target.value })} required />
              </div>
              <div>
                <Label>Color de la fase</Label>
                <Input type="color" value={phaseForm.color} onChange={(event) => setPhaseForm({ ...phaseForm, color: event.target.value })} className="h-10" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-900">Milestones de la fase</div>
                  <div className="text-sm text-slate-500">Cada milestone define una fecha puntual dentro de la duracion de la phase.</div>
                </div>
                <Button type="button" variant="outline" onClick={addPhaseMilestone}>
                  <Plus className="w-4 h-4 mr-1" /> Add milestone
                </Button>
              </div>

              <div className="max-h-[48vh] overflow-y-auto pr-2 space-y-3">
                {phaseForm.milestones.map((milestone, index) => (
                  <div key={milestone.id || index} className="rounded-md border border-slate-200 p-4 space-y-3 bg-slate-50">
                    <div className="flex items-start justify-between gap-3">
                      <div className="font-medium text-slate-900">Milestone {index + 1}</div>
                      <Button type="button" variant="outline" size="sm" onClick={() => removePhaseMilestone(index)}>
                        <Trash2 className="w-4 h-4 mr-1" /> Remove
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <Label>Tipo</Label>
                        <Select value={milestone.type} onValueChange={(value) => updatePhaseMilestone(index, "type", value)}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {TYPES.map((type) => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Fecha</Label>
                        <Input type="date" value={milestone.date} onChange={(event) => updatePhaseMilestone(index, "date", event.target.value)} required />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <Label>Nombre del milestone</Label>
                        <Input value={milestone.name} onChange={(event) => updatePhaseMilestone(index, "name", event.target.value)} required />
                      </div>
                      <div>
                        <Label>Descripcion</Label>
                        <Input value={milestone.description} onChange={(event) => updatePhaseMilestone(index, "description", event.target.value)} placeholder="Opcional" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPhaseDialog(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800">Save phase</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={legacyDialog} onOpenChange={setLegacyDialog}>
        <DialogContent data-testid="legacy-milestone-dialog">
          <DialogHeader>
            <DialogTitle>Edit existing milestone</DialogTitle>
            <DialogDescription>Este cambio mantiene el milestone actual activo en Matrix, Dashboard y reportes.</DialogDescription>
          </DialogHeader>

          <form onSubmit={submitLegacy} className="space-y-3">
            <div>
              <Label>Name</Label>
              <Input value={legacyForm.name} onChange={(event) => setLegacyForm({ ...legacyForm, name: event.target.value })} required />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select
                  value={legacyForm.type}
                  onValueChange={(value) => {
                    const selectedType = TYPES.find((item) => item.value === value);
                    setLegacyForm({ ...legacyForm, type: value, color: selectedType?.color || legacyForm.color });
                  }}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TYPES.map((type) => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date</Label>
                <Input type="date" value={legacyForm.date} onChange={(event) => setLegacyForm({ ...legacyForm, date: event.target.value })} required />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Color</Label>
                <Input type="color" value={legacyForm.color} onChange={(event) => setLegacyForm({ ...legacyForm, color: event.target.value })} className="h-10" />
              </div>
              <div>
                <Label>Description</Label>
                <Input value={legacyForm.description} onChange={(event) => setLegacyForm({ ...legacyForm, description: event.target.value })} placeholder="Optional" />
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setLegacyDialog(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800">Save existing milestone</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
