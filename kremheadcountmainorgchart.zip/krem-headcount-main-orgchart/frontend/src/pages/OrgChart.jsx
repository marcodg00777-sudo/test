import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Users2, UserX } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { api, endpoints } from "@/lib/api";

// Mirrors the Person "status" values used across People.jsx.
const STATUS_CLASS = {
  active:   "bg-emerald-100 text-emerald-700",
  training: "bg-amber-100 text-amber-700",
  inactive: "bg-slate-200 text-slate-600",
  planned:  "bg-blue-100 text-blue-700",
};

function PersonCard({ person }) {
  const isTbd = (person.name || "").trim().toUpperCase() === "TBD";
  const statusClass = STATUS_CLASS[person.status] || STATUS_CLASS.planned;
  return (
    <div
      className="min-w-[170px] max-w-[220px] bg-white border border-slate-200 rounded-md shadow-sm px-3 py-2"
      data-testid={`org-person-${person.id}`}
    >
      <div className="flex items-center gap-1.5 mb-1">
        {person.classification && (
          <span className={`classification-badge class-${person.classification}`}>{person.classification}</span>
        )}
        <span className={`px-1.5 py-0.5 rounded-sm text-[10px] font-semibold ${statusClass}`}>{person.status}</span>
      </div>
      <div className={`font-heading font-semibold text-sm leading-snug ${isTbd ? "text-orange-600" : "text-slate-900"}`}>
        {isTbd ? <span className="inline-flex items-center gap-1"><UserX className="w-3.5 h-3.5" />TBD</span> : person.name}
      </div>
      <div className="text-xs text-slate-500 truncate">{person.position_name || "—"}</div>
      {person.centro_costos && (
        <div className="text-[10px] text-slate-400 mt-0.5">CC {person.centro_costos}</div>
      )}
    </div>
  );
}

function LayerRow({ label, people, dashed }) {
  return (
    <div className="relative pl-6" data-testid={`org-layer-${label.replace(/\s+/g, "-").toLowerCase()}`}>
      <div className={`absolute left-1.5 top-0 bottom-0 w-px ${dashed ? "border-l border-dashed border-slate-300" : "bg-slate-200"}`} />
      <div className="absolute left-1.5 top-5 h-px w-4 bg-slate-200" />
      <div className="pb-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5">{label}</div>
        <div className="flex flex-wrap gap-2.5">
          {people.map((p) => <PersonCard key={p.id} person={p} />)}
        </div>
      </div>
    </div>
  );
}

export default function OrgChartPage() {
  const [areas, setAreas] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const r = await api.get(endpoints.orgChart);
      setAreas(r.data.areas || []);
    } catch {
      toast.error("Failed to load org chart");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  const totalPeople = areas.reduce(
    (sum, a) => sum + a.layers.reduce((s, l) => s + l.people.length, 0) + a.unassigned.length,
    0
  );

  return (
    <>
      <PageHeader
        title="Org Chart"
        subtitle="Every area, top (Layer 1) to bottom (Layer 10). Set each person's Layer from the People page."
        testId="orgchart-header"
      />

      <div className="px-6 lg:px-8 py-6 space-y-6">
        <div className="flex items-center gap-2 text-xs text-slate-500" data-testid="org-counts">
          <Users2 className="w-4 h-4" />
          {areas.length} areas · {totalPeople} people shown
        </div>

        {loading ? (
          <div className="text-sm text-slate-400 text-center py-10">Loading…</div>
        ) : (
          areas.map((area) => {
            const isEmpty = area.layers.length === 0 && area.unassigned.length === 0;
            return (
              <div
                key={area.area_id}
                className="bg-white border border-slate-200 rounded-md p-5"
                data-testid={`org-area-${area.area_id}`}
              >
                <h2 className="font-heading font-bold text-base text-slate-900 mb-4 pb-2 border-b border-slate-100">
                  {area.area_name}
                </h2>
                {isEmpty ? (
                  <div className="text-sm text-slate-400 py-4" data-testid={`org-area-empty-${area.area_id}`}>
                    No people assigned in this area yet.
                  </div>
                ) : (
                  <div>
                    {area.layers.map((l) => (
                      <LayerRow key={l.layer} label={`Layer ${l.layer}`} people={l.people} />
                    ))}
                    {area.unassigned.length > 0 && (
                      <LayerRow label="Unassigned layer" people={area.unassigned} dashed />
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </>
  );
}
