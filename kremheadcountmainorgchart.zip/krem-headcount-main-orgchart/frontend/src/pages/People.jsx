import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Search, UserPlus, X } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import ImportModal from "@/components/ImportModal";

const CLASSES = ["DL", "IL", "DLNUN"];
const ORIGINS = ["KEMMX", "KOMEX"];
const SHIFTS = ["1st", "2nd", "3rd", "N/A"];
const STATUSES = ["planned", "active", "training", "inactive"];

const EMPTY = {
  name: "TBD",
  position_id: "",
  origin: "",
  classification: "",
  shift: "",
  hire_date: "",
  status: "planned",
  employee_id: "",
  notes: "",
  custom_fields: {},
};

export default function PeoplePage() {
  const [importOpen, setImportOpen] = useState(false);
  const [people, setPeople] = useState([]);
  const [positions, setPositions] = useState([]);
  const [areas, setAreas] = useState([]);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [customFieldsList, setCustomFieldsList] = useState([]);

  async function load() {
    const [p, pos, a] = await Promise.all([
      api.get(endpoints.people),
      api.get(endpoints.positions),
      api.get(endpoints.areas),
    ]);
    setPeople(p.data);
    setPositions(pos.data);
    setAreas(a.data);
  }
  useEffect(() => { load(); }, []);

  const areaById = useMemo(() => Object.fromEntries(areas.map((a) => [a.id, a])), [areas]);
  const posById  = useMemo(() => Object.fromEntries(positions.map((p) => [p.id, p])), [positions]);
  const selectedFormPosition = form.position_id ? posById[form.position_id] : null;

  const filtered = useMemo(() => {
    let list = people;
    if (statusFilter !== "all") list = list.filter((p) => p.status === statusFilter);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((p) =>
        (p.name || "").toLowerCase().includes(q) ||
        (p.employee_id || "").toLowerCase().includes(q) ||
        (posById[p.position_id]?.name || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [people, posById, query, statusFilter]);

  // Reset to page 1 whenever the filter changes
  useEffect(() => { setPage(1); }, [query, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paginated = useMemo(
    () => filtered.slice((page - 1) * pageSize, page * pageSize),
    [filtered, page, pageSize]
  );

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setCustomFieldsList([]);
    setDialogOpen(true);
  }

  function openEdit(person) {
    setEditing(person);
    const cfl = Object.entries(person.custom_fields || {})
      .filter(([k]) => k !== "cenco")
      .map(([k, v]) => ({ k, v }));
    setForm({
      name: person.name || "TBD",
      position_id: person.position_id || "",
      origin: person.origin || "",
      classification: person.classification || "",
      shift: person.shift || "",
      hire_date: person.hire_date || "",
      status: person.status || "planned",
      employee_id: person.employee_id || "",
      notes: person.notes || "",
      custom_fields: person.custom_fields || {},
    });
    setCustomFieldsList(cfl);
    setDialogOpen(true);
  }

  async function submit(e) {
    e.preventDefault();
    const custom = {};
    customFieldsList.forEach(({ k, v }) => {
      if (k.trim() && k.trim().toLowerCase() !== "cenco") custom[k.trim()] = v;
    });
    const payload = { ...form, custom_fields: custom };
    // clean empties for optional fields
    if (!payload.position_id) payload.position_id = null;
    if (!payload.origin) payload.origin = null;
    if (!payload.classification) payload.classification = null;
    if (!payload.shift) payload.shift = null;
    if (!payload.hire_date) payload.hire_date = null;
    if (!payload.employee_id) payload.employee_id = null;

    try {
      if (editing) {
        await api.patch(`${endpoints.people}/${editing.id}`, payload);
        toast.success("Person updated");
      } else {
        await api.post(endpoints.people, payload);
        toast.success("Person added");
      }
      setDialogOpen(false);
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Save failed");
    }
  }

  async function remove(person) {
    if (!confirm(`Delete ${person.name}?`)) return;
    try {
      await api.delete(`${endpoints.people}/${person.id}`);
      toast.success("Deleted");
      await load();
    } catch {
      toast.error("Delete failed");
    }
  }

  return (
    <>
      <PageHeader
        title="People"
        subtitle="Roster of team members. Use TBD for open positions."
        testId="people-header"
        actions={
          <>
            <Button data-testid="add-person-btn" onClick={openCreate} className="bg-blue-700 hover:bg-blue-800">
              <UserPlus className="w-4 h-4 mr-2" />
              Add Person
            </Button>
            <Button onClick={() => setImportOpen(true)} className="ml-2">Import</Button>
          </>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input
              data-testid="people-search"
              placeholder="Search name, employee ID, position…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px]" data-testid="people-status-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="ml-auto flex items-center gap-3">
            <Select value={String(pageSize)} onValueChange={(v) => { setPageSize(Number(v)); setPage(1); }}>
              <SelectTrigger className="w-[110px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[10, 25, 50, 100].map((n) => (
                  <SelectItem key={n} value={String(n)}>{n} per page</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="text-sm text-slate-500" data-testid="people-count">
              {filtered.length} of {people.length} people
            </span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr className="text-left">
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Name</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Employee ID</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Position</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Area</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Centro costos</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Class</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Shift</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Origin</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Hire date</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-4 py-10 text-center text-sm text-slate-400" data-testid="people-empty">
                    No people yet. Click <b>Add Person</b> to create one, or leave TBD placeholders for open roles.
                  </td>
                </tr>
              )}
              {paginated.map((p) => {
                const pos = posById[p.position_id];
                const area = pos ? areaById[pos.area_id] : null;
                const isTbd = (p.name || "").trim().toUpperCase() === "TBD";
                return (
                  <tr
                    key={p.id}
                    onClick={() => openEdit(p)}
                    className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors duration-150"
                    data-testid={`person-row-${p.id}`}
                  >
                    <td className="px-4 py-2.5 font-medium text-slate-900">
                      <span className={isTbd ? "px-2 py-0.5 rounded-sm bg-orange-100 text-orange-700 text-xs" : ""}>{p.name}</span>
                    </td>
                    <td className="px-4 py-2.5 text-slate-600 font-mono text-xs">{p.employee_id || "—"}</td>
                    <td className="px-4 py-2.5 text-slate-700">{pos?.name || "—"}</td>
                    <td className="px-4 py-2.5 text-slate-500 text-xs">{area?.name || "—"}</td>
                    <td className="px-4 py-2.5 text-slate-500">{pos?.centro_costos || "—"}</td>
                    <td className="px-4 py-2.5">{p.classification ? <span className={`classification-badge class-${p.classification}`}>{p.classification}</span> : "—"}</td>
                    <td className="px-4 py-2.5 text-slate-500">{p.shift || "—"}</td>
                    <td className="px-4 py-2.5 text-slate-500">{p.origin || "—"}</td>
                    <td className="px-4 py-2.5 text-slate-500">{p.hire_date || "—"}</td>
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded-sm text-xs font-medium ${
                        p.status === "active" ? "bg-emerald-100 text-emerald-700" :
                        p.status === "training" ? "bg-amber-100 text-amber-700" :
                        p.status === "inactive" ? "bg-slate-200 text-slate-600" :
                        "bg-blue-100 text-blue-700"
                      }`}>{p.status}</span>
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <button
                        data-testid={`delete-person-${p.id}`}
                        onClick={(e) => { e.stopPropagation(); remove(p); }}
                        className="text-slate-400 hover:text-red-600 transition-colors duration-150"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4">
            <span className="text-sm text-slate-500">
              Page {page} of {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" onClick={() => setPage(1)} disabled={page === 1}>«</Button>
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>‹</Button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const start = Math.max(1, Math.min(page - 2, totalPages - 4));
                const p = start + i;
                return (
                  <Button
                    key={p}
                    variant={p === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPage(p)}
                    className={p === page ? "bg-blue-700 text-white" : ""}
                  >
                    {p}
                  </Button>
                );
              })}
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}>›</Button>
              <Button variant="outline" size="sm" onClick={() => setPage(totalPages)} disabled={page === totalPages}>»</Button>
            </div>
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="person-dialog">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit person" : "Add person"}</DialogTitle>
            <DialogDescription>Enter name or use TBD for an open slot. Extra fields go under Custom fields.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Full name</Label>
              <Input
                data-testid="form-person-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="TBD"
                required
              />
            </div>
            <div>
              <Label>Employee ID</Label>
              <Input
                data-testid="form-person-empid"
                value={form.employee_id}
                onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
                placeholder="Optional"
              />
            </div>
            <div>
              <Label>Position</Label>
              <Select value={form.position_id} onValueChange={(v) => setForm({ ...form, position_id: v })}>
                <SelectTrigger data-testid="form-person-position"><SelectValue placeholder="Select position…" /></SelectTrigger>
                <SelectContent className="max-h-72">
                  {positions.map((p) => <SelectItem key={p.id} value={p.id}>{p.name} — {areaById[p.area_id]?.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Centro de costos</Label>
              <Input
                data-testid="form-person-centro-costos"
                value={selectedFormPosition?.centro_costos || ""}
                placeholder="Se toma de la posicion"
                disabled
              />
            </div>
            <div>
              <Label>Classification</Label>
              <Select value={form.classification} onValueChange={(v) => setForm({ ...form, classification: v })}>
                <SelectTrigger data-testid="form-person-class"><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  {CLASSES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Shift</Label>
              <Select value={form.shift} onValueChange={(v) => setForm({ ...form, shift: v })}>
                <SelectTrigger data-testid="form-person-shift"><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  {SHIFTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Origin</Label>
              <Select value={form.origin} onValueChange={(v) => setForm({ ...form, origin: v })}>
                <SelectTrigger data-testid="form-person-origin"><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  {ORIGINS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Hire date</Label>
              <Input
                data-testid="form-person-hiredate"
                type="date"
                value={form.hire_date}
                onChange={(e) => setForm({ ...form, hire_date: e.target.value })}
              />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger data-testid="form-person-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>Notes</Label>
              <Input
                data-testid="form-person-notes"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Optional notes"
              />
            </div>

            <div className="md:col-span-2 border-t border-slate-200 pt-3 mt-1">
              <div className="flex items-center justify-between mb-2">
                <div className="text-overline">Custom fields</div>
                <button
                  type="button"
                  data-testid="add-custom-field"
                  onClick={() => setCustomFieldsList([...customFieldsList, { k: "", v: "" }])}
                  className="text-xs text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add field
                </button>
              </div>
              <div className="space-y-2">
                {customFieldsList.map((cf, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <Input
                      placeholder="Field name"
                      value={cf.k}
                      onChange={(e) => {
                        const list = [...customFieldsList];
                        list[idx] = { ...list[idx], k: e.target.value };
                        setCustomFieldsList(list);
                      }}
                      data-testid={`cf-key-${idx}`}
                    />
                    <Input
                      placeholder="Value"
                      value={cf.v}
                      onChange={(e) => {
                        const list = [...customFieldsList];
                        list[idx] = { ...list[idx], v: e.target.value };
                        setCustomFieldsList(list);
                      }}
                      data-testid={`cf-value-${idx}`}
                    />
                    <button
                      type="button"
                      onClick={() => setCustomFieldsList(customFieldsList.filter((_, i) => i !== idx))}
                      className="text-slate-400 hover:text-red-600"
                      data-testid={`cf-remove-${idx}`}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                {customFieldsList.length === 0 && (
                  <div className="text-xs text-slate-400">No custom fields.</div>
                )}
              </div>
            </div>

            <DialogFooter className="md:col-span-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="cancel-person-btn">Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800" data-testid="save-person-btn">
                {editing ? "Save changes" : "Add person"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      <ImportModal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        endpoint={`${process.env.REACT_APP_BACKEND_URL}/api/people/import`}
        title="Importar People - Digitalización"
      />
    </>
  );
}
