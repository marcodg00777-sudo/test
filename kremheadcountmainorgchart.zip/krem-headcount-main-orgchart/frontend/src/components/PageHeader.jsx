export default function PageHeader({ title, subtitle, actions, testId }) {
  return (
    <div className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-20" data-testid={testId}>
      <div className="px-6 lg:px-8 py-4 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">KREM Plant · Headcount</div>
          <h1 className="font-heading font-bold text-xl sm:text-2xl text-slate-900 tracking-tight truncate">{title}</h1>
          {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
      </div>
    </div>
  );
}
