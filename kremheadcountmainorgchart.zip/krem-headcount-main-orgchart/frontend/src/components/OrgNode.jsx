import { memo } from "react";
import { ChevronDown, ChevronRight, User, UserX, Pencil } from "lucide-react";

// Mirrors POSITION_STATUSES in backend/server.py — keep these two in sync.
const STATUS_COLORS = {
  hired:    "bg-emerald-100 text-emerald-700 border-emerald-200",
  vacant:   "bg-rose-100 text-rose-700 border-rose-200",
  tbd:      "bg-orange-100 text-orange-700 border-orange-200",
  planned:  "bg-blue-100 text-blue-700 border-blue-200",
  temp:     "bg-purple-100 text-purple-700 border-purple-200",
  transfer: "bg-slate-100 text-slate-700 border-slate-200",
};

const LEVEL_COLORS = ["#1e3a8a", "#1e40af", "#2563eb", "#3b82f6", "#60a5fa", "#93c5fd", "#dbeafe"];

function OrgNodeInner({ node, showPeople, expanded, toggle, onEdit }) {
  const children = node.children || [];
  const hasKids = children.length > 0;
  const isOpen = expanded[node.id] !== false;
  const people = node.assigned || [];
  const status = node.status || "planned";
  const levelColor = LEVEL_COLORS[(node.org_level || 1) - 1] || "#94a3b8";
  const statusColor = STATUS_COLORS[status] || STATUS_COLORS.planned;
  const areaLabel = node.centro_costos
    ? `${node.area_name} · CC ${node.centro_costos}`
    : node.area_name;

  return (
    <div
      className="pl-4 border-l-2 border-slate-200 relative"
      data-testid={`org-node-${node.id}`}
    >
      <div className="absolute left-0 top-5 h-px w-3 bg-slate-200" />
      <div
        className="ml-2 my-2 group inline-flex items-start gap-2 py-2 pl-3 pr-4 bg-white border-l-4 rounded-md shadow-sm hover:shadow-md transition-shadow duration-150"
        style={{ borderLeftColor: levelColor }}
      >
        {hasKids ? (
          <button
            onClick={() => toggle(node.id)}
            data-testid={`org-toggle-${node.id}`}
            className="mt-1 text-slate-400 hover:text-slate-700"
          >
            {isOpen ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </button>
        ) : (
          <span className="w-4 h-4 mt-1" />
        )}
        <div className="min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span
              className="text-[10px] font-bold uppercase tracking-widest text-white px-1.5 py-0.5 rounded-sm"
              style={{ backgroundColor: levelColor }}
            >
              L{node.org_level ?? "?"}
            </span>
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-sm border ${statusColor}`}
            >
              {status}
            </span>
            <span className="text-xs text-slate-400">{areaLabel}</span>
          </div>
          <div className="font-heading font-semibold text-slate-900 text-sm leading-snug">
            {node.name}
          </div>
          {showPeople ? (
            <div className="mt-1.5 flex items-center gap-1.5 text-xs">
              {people.length === 0 ? (
                <span className="inline-flex items-center gap-1 text-orange-600">
                  <UserX className="w-3.5 h-3.5" /> Open
                </span>
              ) : (
                people.map((pe) => {
                  const nameUpper = (pe.name || "TBD").toUpperCase();
                  return (
                    <span
                      key={pe.id}
                      className="inline-flex items-center gap-1 text-slate-600"
                    >
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {nameUpper === "TBD" ? (
                        <span className="text-orange-600">TBD</span>
                      ) : (
                        pe.name
                      )}
                    </span>
                  );
                })
              )}
            </div>
          ) : null}
        </div>
        <button
          onClick={() => onEdit(node)}
          data-testid={`org-edit-${node.id}`}
          className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-blue-700"
          title="Edit reporting line"
        >
          <Pencil className="w-4 h-4" />
        </button>
      </div>
      {hasKids && isOpen ? (
        <div className="mt-1">
          {children.map((c) => (
            <OrgNode
              key={c.id}
              node={c}
              showPeople={showPeople}
              expanded={expanded}
              toggle={toggle}
              onEdit={onEdit}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

const OrgNode = memo(OrgNodeInner);
OrgNode.displayName = "OrgNode";

export default OrgNode;
