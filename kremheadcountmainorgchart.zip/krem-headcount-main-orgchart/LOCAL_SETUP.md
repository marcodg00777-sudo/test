# KREM Headcount Planner — Guía de instalación local

Corre esta aplicación en tu PC con MongoDB local. Todos tus datos se guardan localmente.

---

## 1. Prerrequisitos (instalar una sola vez)

| Software | Versión | Descarga |
|---|---|---|
| **Python** | 3.11 o superior | https://www.python.org/downloads/ — ⚠️ **En Windows marca "Add Python to PATH"** |
| **Node.js** | 20 o superior | https://nodejs.org/ (LTS) |
| **MongoDB Community** | 6.x o 7.x | https://www.mongodb.com/try/download/community — en Windows deja activada la opción "Install as a service" |
| **Git** (opcional) | — | https://git-scm.com/ |

En macOS puedes usar Homebrew:
```bash
brew install python@3.11 node mongodb-community
brew services start mongodb-community
```

En Linux (Ubuntu/Debian):
```bash
sudo apt install python3 python3-venv nodejs npm
# MongoDB: https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-ubuntu/
sudo systemctl start mongod
```

---

## 2. Descargar el código

Ya conectaste GitHub, así que puedes clonar tu repo:

```bash
git clone https://github.com/<tu-usuario>/<tu-repo>.git
cd <tu-repo>
```

---

## 3. Instalación (una sola vez)

### Windows
Doble clic en **`install.bat`** (dentro de la carpeta del proyecto).

El script:
- Verifica Python, Node, Yarn y MongoDB
- Crea el entorno virtual de Python (`backend/.venv`)
- Instala dependencias del backend (FastAPI, MongoDB driver, openpyxl, reportlab…)
- Instala dependencias del frontend (React, Tailwind, Recharts…)
- Crea archivos `.env` con valores por defecto

**Crear acceso directo en el escritorio (opcional pero recomendado):**
Doble clic en **`create-desktop-shortcut.bat`**. Aparecerá un acceso directo llamado **"KREM Planner"** en tu escritorio con el icono azul de la app. Doble clic en él para arrancar todo.

### Mac / Linux
Abre una terminal en la carpeta del proyecto:
```bash
chmod +x install.sh start.sh create-desktop-shortcut.sh
./install.sh
```

En **Linux**, después de instalar, ejecuta:
```bash
./create-desktop-shortcut.sh
```
Aparecerá un lanzador en `~/Desktop/` con el icono personalizado.

En **macOS** no hay acceso directo automático, pero puedes arrastrar `start.sh` al Dock o crear un shortcut con Automator.

---

## 4. Arrancar la app (uso diario)

### Windows
Doble clic en **`start.bat`**.

El script abre dos ventanas de consola (backend + frontend) y abre el navegador en http://localhost:3000 automáticamente.

Para detener la app, cierra las dos ventanas.

### Mac / Linux
```bash
./start.sh
```

Detén con **Ctrl+C** (esto para backend y frontend juntos).

---

## 5. Primer uso

1. Cuando el navegador abra en http://localhost:3000, ve a **Dashboard**.
2. Haz clic en **"Load KREM defaults"** para poblar áreas, posiciones y milestones desde tu plantilla.
3. Empieza a capturar números en la **Matrix**, personas en **People** y ajusta **Milestones** cuando cambien las fechas.
4. Descarga tu reporte desde **Reports** (XLSX o PDF).

Todos los datos quedan en tu MongoDB local. Nada se envía a la nube.

---

## 6. Configuración

Los archivos `.env` los creó el instalador con estos valores por defecto:

**`backend/.env`**
```ini
MONGO_URL=mongodb://localhost:27017
DB_NAME=krem_headcount
CORS_ORIGINS=*
```

**`frontend/.env`**
```ini
REACT_APP_BACKEND_URL=http://localhost:8001
WDS_SOCKET_PORT=0
```

Cambia `DB_NAME` si quieres separar entornos (por ejemplo `krem_headcount_test`).

---

## 7. Respaldo / Backup de tus datos

Para hacer copia de seguridad de toda la BD:
```bash
mongodump --db krem_headcount --out ./backup-$(date +%Y%m%d)
```

Restaurar:
```bash
mongorestore ./backup-YYYYMMDD
```

---

## 8. Problemas comunes

| Síntoma | Solución |
|---|---|
| Windows dice "python no se reconoce…" | Reinstala Python marcando "Add Python to PATH", o usa `py` en lugar de `python`. |
| `MongoDB is not reachable on port 27017` | Windows: abre `services.msc` → busca **MongoDB** → clic derecho → **Iniciar**. macOS: `brew services start mongodb-community`. Linux: `sudo systemctl start mongod`. |
| El frontend abre pero muestra "Failed to load dashboard data" | El backend no está corriendo, o `REACT_APP_BACKEND_URL` en `frontend/.env` no apunta a `http://localhost:8001`. |
| Puerto 8001 o 3000 ocupado | Cambia el puerto en `start.bat`/`start.sh` **y** actualiza `REACT_APP_BACKEND_URL` en `frontend/.env`. |
| `yarn: command not found` | `npm install -g yarn` |
| El instalador falla con `pip install` | Comprueba tu versión de Python: `python --version` (necesita 3.11+). |

---

## 9. Actualizar la app cuando hagas cambios en Emergent

1. En Emergent: **"Save to GitHub"** (push a la rama que uses).
2. En tu PC:
   ```bash
   git pull
   ./install.sh    # (o install.bat) por si cambiaron dependencias
   ./start.sh      # (o start.bat)
   ```

---

¡Listo! Tu KREM Headcount Planner corriendo 100% offline en tu PC. 🎯
