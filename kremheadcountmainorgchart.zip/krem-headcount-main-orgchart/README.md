# KREM Plant Headcount Planner

Aplicación web para reemplazar la planeación de headcount en Excel de la planta KREM.
Corre 100% en tu propia PC usando MongoDB local.

## Arranque rápido en local

### Windows
1. Instala Python 3.11+, Node 20+ y MongoDB Community (deja MongoDB como servicio).
2. Doble clic en **`install.bat`** (una sola vez).
3. Doble clic en **`create-desktop-shortcut.bat`** para poner el icono en tu escritorio (una sola vez).
4. Doble clic en **"KREM Planner"** en el escritorio — el navegador abre solo en http://localhost:3000.

### Mac / Linux
```bash
chmod +x install.sh start.sh create-desktop-shortcut.sh
./install.sh                       # una sola vez
./create-desktop-shortcut.sh       # sólo Linux, opcional
./start.sh                         # cada vez que quieras usar la app
```

Ver la guía completa en **[LOCAL_SETUP.md](./LOCAL_SETUP.md)** (prerrequisitos, backup, troubleshooting).

## Estructura

```
/backend                        FastAPI + MongoDB (Motor)
/frontend                       React + Tailwind + shadcn/ui + Recharts
/assets/krem-planner.ico        Desktop icon (Windows)
/assets/krem-planner.png        Desktop icon (Linux/preview)
/install.bat|.sh                Instalador de dependencias (una vez)
/start.bat|.sh                  Launcher (levanta backend, frontend y abre navegador)
/create-desktop-shortcut.bat|.sh  Crea acceso directo con icono en el escritorio
/LOCAL_SETUP.md                 Guía detallada
```

## Funcionalidades

- **Dashboard** con KPIs, gráficas semanales (DL/IL/DLNUN) y trend line.
- **Matrix** estilo Excel: posiciones × 52 semanas calendario, celdas editables, columnas de milestones destacadas.
- **People** con placeholders TBD y campos personalizados.
- **Positions & Areas** editables desde la UI.
- **Milestones** (Transfer / Trial Run / SOP) con fechas editables.
- **Reports** — exporta la vista general a XLSX y PDF.

## Puertos por defecto
- Backend FastAPI: **8001**
- Frontend React: **3000**
- MongoDB: **27017**

## Licencia
Uso interno KREM.
