"""Regression tests for the Org Chart hierarchy endpoint.

Focus:
- GET /api/positions/hierarchy returns roots[] with children[] and assigned[].
- Filter ?area_id=<id> filters positions to that area.
- PATCH /api/positions/{id} accepts level (1-7) and reports_to_position_id.
- PATCH validation: level out of range -> 400.
- POST /api/areas rejects cost_center that is not 5 digits.
"""
from __future__ import annotations

import os

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1].rstrip("/")
                break
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def client():
    return requests.Session()


@pytest.fixture(scope="module", autouse=True)
def seeded(client):
    r = client.post(f"{API}/seed", timeout=30)
    assert r.status_code == 200
    yield
    # Cleanup TEST_ artefacts
    positions = client.get(f"{API}/positions").json()
    for p in positions:
        if p.get("name", "").startswith("TEST_"):
            client.delete(f"{API}/positions/{p['id']}")
    areas = client.get(f"{API}/areas").json()
    for a in areas:
        if a.get("name", "").startswith("TEST_"):
            try:
                client.delete(f"{API}/areas/{a['id']}")
            except Exception:
                pass


class TestHierarchy:
    def test_hierarchy_shape(self, client):
        r = client.get(f"{API}/positions/hierarchy")
        assert r.status_code == 200
        data = r.json()
        assert "roots" in data
        assert isinstance(data["roots"], list)
        for root in data["roots"]:
            assert "children" in root and isinstance(root["children"], list)
            assert "assigned" in root and isinstance(root["assigned"], list)
            assert "area_name" in root

    def test_hierarchy_filter_by_area(self, client):
        areas = client.get(f"{API}/areas").json()
        area = areas[0]
        r = client.get(f"{API}/positions/hierarchy", params={"area_id": area["id"]})
        assert r.status_code == 200
        data = r.json()

        def walk(node):
            assert node["area_id"] == area["id"], node
            for c in node["children"]:
                walk(c)

        for root in data["roots"]:
            walk(root)

    def test_hierarchy_assigned_contains_people(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/people", json={"name": "TEST_HIER_Person", "position_id": pid})
        assert r.status_code == 200
        try:
            hdata = client.get(f"{API}/positions/hierarchy").json()

            def find(nodes, target_pid):
                for n in nodes:
                    if n["id"] == target_pid:
                        return n
                    got = find(n["children"], target_pid)
                    if got:
                        return got
                return None

            found = find(hdata["roots"], pid)
            assert found is not None, "position missing from hierarchy"
            names = [a["name"] for a in found["assigned"]]
            assert "TEST_HIER_Person" in names
        finally:
            client.delete(f"{API}/people/{r.json()['id']}")


class TestPositionLevel:
    def test_patch_level_and_reports_to(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        r1 = client.post(f"{API}/positions", json={
            "name": "TEST_LVL_Root", "area_id": aid, "classification": "IL", "level": 1
        })
        assert r1.status_code == 200, r1.text
        root_id = r1.json()["id"]

        r2 = client.post(f"{API}/positions", json={
            "name": "TEST_LVL_Child", "area_id": aid, "classification": "IL"
        })
        assert r2.status_code == 200
        child_id = r2.json()["id"]

        r = client.patch(f"{API}/positions/{child_id}", json={
            "level": 3, "reports_to_position_id": root_id
        })
        assert r.status_code == 200, r.text
        got = r.json()
        assert got["level"] == 3
        assert got["reports_to_position_id"] == root_id

        r = client.patch(f"{API}/positions/{child_id}", json={"state": "vacant"})
        assert r.status_code == 200
        assert r.json().get("state") == "vacant"

        client.delete(f"{API}/positions/{child_id}")
        client.delete(f"{API}/positions/{root_id}")

    def test_patch_level_out_of_range_rejected(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.patch(f"{API}/positions/{pid}", json={"level": 99})
        assert r.status_code == 400


class TestAreaCostCenter:
    def test_cost_center_bad_digits_rejected(self, client):
        r = client.post(f"{API}/areas", json={
            "name": "TEST_CC_Bad", "code": "TCB", "cost_center": "123"
        })
        assert r.status_code == 400
        assert "5" in (r.json().get("detail") or "")

    def test_cost_center_letters_rejected(self, client):
        r = client.post(f"{API}/areas", json={
            "name": "TEST_CC_Letters", "code": "TCL", "cost_center": "ABCDE"
        })
        assert r.status_code == 400

    def test_cost_center_valid_accepted(self, client):
        r = client.post(f"{API}/areas", json={
            "name": "TEST_CC_OK", "code": "TCO", "cost_center": "12345"
        })
        assert r.status_code == 200, r.text
        aid = r.json()["id"]
        client.delete(f"{API}/areas/{aid}")
