import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Users, Pencil, Layers, Circle } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import OrgNode from "@/components/OrgNode";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { api, endpoints } from "@/lib/api";

const STATE_COLORS = {
  occupied: "bg-emerald-100 text-emerald-700 border-emerald-200",
  vacant:   "bg-rose-100 text-rose-700 border-rose-200",
  tbd:      "bg-orange-100 text-orange-700 border-orange-200",
  planned:  "bg-blue-100 text-blue-700 border-blue-200",
};
const LEVEL_COLORS = ["#1e3a8a", "#1e40af", "#2563eb", "#3b82f6", "#60a5fa", "#93c5fd", "#dbeafe"];
const STATES = ["occupied", "vacant", "tbd", "planned"];
const CLASSES = ["DL", "IL", "DLNUN"];

export default function OrgChartPage() {
  const [tree, setTree] = useState([]);
  const [areas, setAreas] = useState([]);
  const [positions, setPositions] = useState([]);
  const [filter, setFilter] = useState({ area_id: "all" });
  const [showPeople, setShowPeople] = useState(true);
  const [expanded, setExpanded] = useState({});
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const params = filter.area_id !== "all" ? `?area_id=${filter.area_id}` : "";
      const [h, a, p] = await Promise.all([
        api.get(`/positions/hierarchy${params}`),
        api.get(endpoints.areas),
        api.get(endpoints.positions),
      ]);
      setTree(h.data.roots || []);
      setAreas(a.data);
      setPositions(p.data);
    } catch {
      toast.error("Failed to load org chart");
    } finally {
      setLoading(false);
    }
  }
  // eslint-disable-next-line
  useEffect(() => { load(); }, [filter.area_id]);

  const areaById = useMemo(
    () => Object.fromEntries(areas.map((a) => [a.id, a])),
    [areas]
  );
  const activeAreas = areas.filter((a) => !a.archived);
  const archivedAreas = areas.filter((a) => a.archived);

  function openEdit(node) {
    setEditing(node);
    setForm({
      name: node.name || "",
      area_id: node.area_id || "",
      classification: node.classification || "IL",
      shift: node.shift || "N/A",
      level: node.level == null ? "" : node.level,
      reports_to_position_id: node.reports_to_position_id || "",
      state: node.state || "planned",
    });
  }

  async function saveEdit(e) {
    e.preventDefault();
    try {
      const payload = { ...form };
      payload.level = payload.level === "" ? null : parseInt(payload.level, 10);
      if (!payload.reports_to_position_id) payload.reports_to_position_id = null;
      await api.patch(`${endpoints.positions}/${editing.id}`, payload);
      toast.success("Position updated");
      setEditing(null);
      await load();
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Update failed");
    }
  }

  function toggle(id) {
    setExpanded((prev) => ({
      ...prev,
      [id]: prev[id] === false ? true : false,
    }));
  }
  function walkIds(nodes, map, value) {
    nodes.forEach((n) => {
      map[n.id] = value;
      walkIds(n.children || [], map, value);
    });
  }
  function expandAll() {
    const map = {};
    walkIds(tree, map, true);
    setExpanded(map);
  }
  function collapseAll() {
    const map = {};
    walkIds(tree, map, false);
    setExpanded(map);
  }

  const reportsToChoices = useMemo(() => {
    if (!editing) return positions;
    const currentLevel = form.level === "" ? null : parseInt(form.level, 10);
    return positions.filter((p) => {
      if (p.id === editing.id) return false;
      if (!currentLevel || !p.level) return true;
      return p.level < currentLevel;
    });
  }, [positions, editing, form.level]);

  const rootCount = tree.length;
  const totalNodes = useMemo(() => {
    let count = 0;
    function walk(nodes) {
      nodes.forEach((n) => {
        count += 1;
        walk(n.children || []);
      });
    }
    walk(tree);
    return count;
  }, [tree]);

  return (
    <>
      <PageHeader
        title="Org Chart"
        subtitle="Hierarchical view of positions and people. Levels 1 (top) → 7 (bottom)."
        testId="orgchart-header"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={expandAll}
              data-testid="org-expand-all"
            >
              Expand all
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={collapseAll}
              data-testid="org-collapse-all"
            >
              Collapse all
            </Button>
          </div>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-4">
        <div className="flex flex-wrap items-center gap-4 bg-white border border-slate-200 rounded-md p-4">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-500" />
            <span className="text-overline">Area</span>
            <Select
              value={filter.area_id}
              onValueChange={(v) => setFilter({ ...filter, area_id: v })}
            >
              <SelectTrigger className="w-[200px]" data-testid="org-area-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All plant</SelectItem>
                {activeAreas.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.cost_center ? `${a.name} (CC ${a.cost_center})` : a.name}
                  </SelectItem>
                ))}
                {archivedAreas.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name} (archived)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" />
            <span className="text-overline">View</span>
            <button
              type="button"
              onClick={() => setShowPeople(false)}
              data-testid="org-view-positions"
              className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                !showPeople
                  ? "bg-blue-700 text-white border-blue-700"
                  : "bg-white text-slate-500 border-slate-300"
              }`}
            >
              Positions only
            </button>
            <button
              type="button"
              onClick={() => setShowPeople(true)}
              data-testid="org-view-people"
              className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                showPeople
                  ? "bg-blue-700 text-white border-blue-700"
                  : "bg-white text-slate-500 border-slate-300"
              }`}
            >
              Positions + People
            </button>
          </div>

          <div className="ml-auto text-xs text-slate-500" data-testid="org-counts">
            {rootCount} root{rootCount === 1 ? "" : "s"} · {totalNodes} total position{totalNodes === 1 ? "" : "s"}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-overline">Levels</span>
          {[1, 2, 3, 4, 5, 6, 7].map((lvl) => (
            <span
              key={lvl}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-white font-semibold"
              style={{ backgroundColor: LEVEL_COLORS[lvl - 1] }}
            >
              L{lvl}
            </span>
          ))}
          <span className="mx-2 text-slate-300">|</span>
          <span className="text-overline">State</span>
          {STATES.map((s) => (
            <span
              key={s}
              className={`px-2 py-0.5 rounded-sm border font-semibold ${STATE_COLORS[s]}`}
            >
              {s}
            </span>
          ))}
        </div>

        <div
          className="bg-white border border-slate-200 rounded-md p-4 min-h-[200px]"
          data-testid="org-tree"
        >
          {loading ? (
            <div className="text-sm text-slate-400 text-center py-10">Loading…</div>
          ) : tree.length === 0 ? (
            <div className="text-center py-16" data-testid="org-empty">
              <Circle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <div className="text-sm text-slate-500 mb-1">
                No positions to display yet.
              </div>
              <div className="text-xs text-slate-400">
                Set a <b>level</b> on some positions (from the Positions page) so
                they appear in the hierarchy.
              </div>
            </div>
          ) : (
            tree.map((n) => (
              <OrgNode
                key={n.id}
                node={n}
                showPeople={showPeople}
                expanded={expanded}
                toggle={toggle}
                onEdit={openEdit}
              />
            ))
          )}
        </div>
      </div>

      <Dialog
        open={!!editing}
        onOpenChange={(o) => {
          if (!o) setEditing(null);
        }}
      >
        <DialogContent data-testid="org-edit-dialog">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-4 h-4" />
              Edit position
            </DialogTitle>
            <DialogDescription>
              Adjust level or reporting line — changes reflect across the app.
            </DialogDescription>
          </DialogHeader>
          {editing ? (
            <form onSubmit={saveEdit} className="space-y-3">
              <div>
                <Label>Name</Label>
                <Input
                  data-testid="org-form-name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label>Area</Label>
                  <Select
                    value={form.area_id}
                    onValueChange={(v) => setForm({ ...form, area_id: v })}
                  >
                    <SelectTrigger data-testid="org-form-area">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {areas.map((a) => (
                        <SelectItem key={a.id} value={a.id}>
                          {a.name}
                          {a.archived ? " (archived)" : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Level (1-7)</Label>
                  <Select
                    value={form.level === "" ? "unset" : String(form.level)}
                    onValueChange={(v) =>
                      setForm({
                        ...form,
                        level: v === "unset" ? "" : parseInt(v, 10),
                      })
                    }
                  >
                    <SelectTrigger data-testid="org-form-level">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unset">TBD (unset)</SelectItem>
                      {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                        <SelectItem key={n} value={String(n)}>
                          Level {n}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>State</Label>
                  <Select
                    value={form.state}
                    onValueChange={(v) => setForm({ ...form, state: v })}
                  >
                    <SelectTrigger data-testid="org-form-state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Classification</Label>
                  <Select
                    value={form.classification}
                    onValueChange={(v) =>
                      setForm({ ...form, classification: v })
                    }
                  >
                    <SelectTrigger data-testid="org-form-class">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CLASSES.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Reports to</Label>
                  <Select
                    value={form.reports_to_position_id || "none"}
                    onValueChange={(v) =>
                      setForm({
                        ...form,
                        reports_to_position_id: v === "none" ? "" : v,
                      })
                    }
                  >
                    <SelectTrigger data-testid="org-form-reports-to">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectItem value="none">— (top of hierarchy)</SelectItem>
                      {reportsToChoices.map((p) => {
                        const lvl = p.level ? `L${p.level}` : "L?";
                        const areaName = areaById[p.area_id]?.name || "?";
                        return (
                          <SelectItem key={p.id} value={p.id}>
                            [{lvl}] {p.name} — {areaName}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditing(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-700 hover:bg-blue-800"
                  data-testid="org-save-btn"
                >
                  Save
                </Button>
              </DialogFooter>
            </form>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}
